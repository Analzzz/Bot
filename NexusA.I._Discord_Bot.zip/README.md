# NexusA.I. Discord Bot

A highly sophisticated and modular Discord bot, powered by the Google Gemini API for advanced AI capabilities, including deep comprehension, code generation/optimization, and contextualized interaction. It incorporates concepts of neural networks for long-term memory, knowledge graphs, reflection/self-evaluation modules, and a simulated multi-agent architecture, with a focus on continuous learning and explainability. Developed in Python with advanced software architecture principles.

## Features

*   **Advanced Artificial Intelligence**: Deep comprehension and generation capabilities via Google Gemini API.
*   **Long-Term Context Management**: Utilizes memory techniques to maintain relevance in extended conversations.
*   **Knowledge Graph Integration**: Stores and efficiently retrieves facts and relationships using knowledge graphs.
*   **Reflection and Self-Evaluation**: Allows the bot to analyze and improve its own responses and processes.
*   **Simulated Multi-Agent Architecture**: Decomposes and solves complex tasks collaboratively.
*   **Programmatic Code Generation & Optimization**: Understands requirements and refines code.
*   **Flexible, Contextualized, and Natural Interaction**: Engages with Discord users in a natural way.
*   **Explainability**: Ability to explain its own reasoning, decisions, and internal processes.
*   **Continuous Learning Simulation**: Adapts and improves its knowledge over time.
*   **Modular and Scalable Structure**: Developed with advanced software architecture principles for easy maintenance and expansion.

## Technologies Used (Stack)

*   **Python**: The core programming language.
*   **discord.py**: A modern, easy-to-use, and feature-rich wrapper for the Discord API.
*   **Google Gemini API**: For advanced AI capabilities (text generation, code generation, etc.).
*   **Advanced Natural Language Processing (NLP) Libraries**: (e.g., Hugging Face Transformers for specific context architectures - *Note: Specific implementation details for Hugging Face are not yet detailed in the provided files, but the project description mentions it.*)
*   **Knowledge Graph Libraries**: (e.g., NetworkX or drivers for Graph Databases like Neo4j - *Note: Current implementation uses SQLAlchemy for persistence, implying a relational representation of the graph. Future iterations might integrate dedicated graph DBs.*)
*   **SQLAlchemy**: An SQL toolkit and Object Relational Mapper (ORM) for Python, used for database interactions and persistence.
*   **python-dotenv**: For managing environment variables securely.

## Installation

Follow these steps to set up and run the NexusA.I. Discord Bot on your local machine.

### Prerequisites

*   Python 3.8+
*   Git

### Steps

1.  **Clone the repository**:
    ```bash
    git clone https://github.com/your-username/NexusA.I.-Discord-Bot.git
    cd NexusA.I.-Discord-Bot
    ```
    *(Replace `https://github.com/your-username/NexusA.I.-Discord-Bot.git` with the actual repository URL)*

2.  **Create a virtual environment**:
    It's highly recommended to use a virtual environment to manage dependencies.
    ```bash
    python -m venv venv
    ```

3.  **Activate the virtual environment**:
    *   **On Windows**:
        ```bash
        .\venv\Scripts\activate
        ```
    *   **On macOS/Linux**:
        ```bash
        source venv/bin/activate
        ```

4.  **Install dependencies**:
    All required Python packages are listed in `requirements.txt`.
    ```bash
    pip install -r requirements.txt
    ```

5.  **Configure environment variables**:
    Create a `.env` file in the `config/` directory based on `config/.env` example.
    ```
    # config/.env
    DISCORD_BOT_TOKEN="YOUR_DISCORD_BOT_TOKEN_HERE"
    GOOGLE_GEMINI_API_KEY="YOUR_GOOGLE_GEMINI_API_KEY_HERE"
    DATABASE_URL="sqlite:///./data/nexusai.db"
    LOG_LEVEL="INFO" # Options: DEBUG, INFO, WARNING, ERROR, CRITICAL
    ```
    *   **`DISCORD_BOT_TOKEN`**: Obtain this from the [Discord Developer Portal](https://discord.com/developers/applications). Create a new application, go to the "Bot" tab, and click "Add Bot". Copy the token. **Keep this token secret!**
    *   **`GOOGLE_GEMINI_API_KEY`**: Obtain this from the [Google AI Studio](https://aistudio.google.com/app/apikey).
    *   **`DATABASE_URL`**: Specifies the database connection string. The default `sqlite:///./data/nexusai.db` will create a SQLite database file in the `data` directory.
    *   **`LOG_LEVEL`**: Sets the logging verbosity.

6.  **Database Initialization**:
    The bot will automatically initialize the SQLite database schema on first run if it doesn't exist, based on the models defined in `src/data/models.py`.

## Usage

1.  **Run the bot**:
    Ensure your virtual environment is active and you are in the project's root directory.
    ```bash
    python main.py
    ```
    The bot should now be online on Discord.

2.  **Invite the bot to your server**:
    Go to the Discord Developer Portal, select your application, navigate to "OAuth2" -> "URL Generator". Select `bot` scope and necessary permissions (e.g., `Read Messages/View Channels`, `Send Messages`, `Manage Messages` for moderation, `Embed Links`). Copy the generated URL and paste it into your browser to invite the bot to your desired server.

## Bot Commands

The bot uses `!` as its default prefix (configurable in `config/settings.py`).

### General Commands

*   `!help`: Displays a list of available commands and their descriptions.
*   `!ping`: Checks the bot's latency to the Discord API.
*   `!info`: Provides general information about the bot.

### AI Commands

*   `!ask <query>`: Interacts with the AI for general questions, creative writing, or information retrieval.
    *   Example: `!ask Explain quantum entanglement in simple terms.`
*   `!generate_code <language> <description>`: Generates code snippets based on a given programming language and description.
    *   Example: `!generate_code python a function to reverse a string`
*   `!optimize_code <language> <code_snippet>`: Optimizes a provided code snippet for a specific language.
    *   Example: `!optimize_code python def factorial(n): if n == 0: return 1 else: return n * factorial(n-1)`
*   `!explain <concept or process>`: Asks the AI to provide a detailed explanation of a given concept or internal bot process.
    *   Example: `!explain how your long-term memory works`
*   `!reflect <message_id>`: Triggers the bot's self-evaluation mechanism on a specific message (useful for refining future responses).
    *   Example: `!reflect 1234567890123456789` (replace with actual message ID)

## Architecture Overview

The NexusA.I. Discord Bot is designed with a modular and layered architecture to ensure scalability, maintainability, and extensibility.

*   **`main.py`**: The entry point of the application, responsible for loading configurations, setting up logging, initializing the database, and starting the Discord bot client.
*   **`config/`**: Contains configuration files (`.env` for secrets, `settings.py` for application-wide constants).
*   **`src/core/`**: Core functionalities of the bot, including:
    *   `bot_client.py`: Defines the main Discord bot client and initializes cogs.
    *   `database_manager.py`: Handles all database connections and session management using SQLAlchemy.
*   **`src/data/`**: Defines the database schema using SQLAlchemy ORM models (`models.py`).
*   **`src/modules/discord_commands/`**: Houses Discord command cogs, separating general commands from AI-specific interactions.
    *   `general_commands.py`: Basic utility commands.
    *   `ai_commands.py`: Commands that interface with the AI engine.
*   **`src/ai_engine/`**: The heart of the bot's intelligence, containing various AI sub-modules:
    *   `gemini_integrator.py`: Manages communication with the Google Gemini API.
    *   **`context_memory/`**:
        *   `long_term_memory.py`: Manages persistent conversation context and knowledge.
        *   `short_term_memory.py`: Handles immediate conversational context.
    *   **`knowledge_graph/`**:
        *   `graph_builder.py`: Constructs and updates the knowledge graph.
        *   `graph_query.py`: Queries the knowledge graph for relevant information.
    *   **`reflection/`**:
        *   `self_evaluator.py`: Analyzes bot responses for quality and identifies areas for improvement.
        *   `feedback_loop.py`: Integrates self-evaluation results to refine knowledge and behavior.
    *   **`multi_agent/`**:
        *   `orchestrator.py`: Coordinates interactions between different simulated AI agents.
        *   `agent_definitions.py`: Defines the roles and capabilities of various agents.
    *   **`code_generation/`**:
        *   `code_generator.py`: Generates code based on user prompts.
        *   `code_optimizer.py`: Refines and optimizes existing code.
    *   **`explainability/`**:
        *   `process_explainer.py`: Enables the bot to explain its internal reasoning and decision-making processes.

## Contributing

Contributions are welcome! Please feel free to open issues, submit pull requests, or suggest improvements.

## License

This project is licensed under the MIT License - see the LICENSE file for details.