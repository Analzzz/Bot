import pytest
import asyncio
import discord
from discord.ext import commands
from unittest.mock import AsyncMock, patch, MagicMock
import os
import sys
import logging
import shutil

# Adjust path to import from src
sys.path.insert(0, os.path.abspath(os.path.join(os.path.dirname(__file__), '../../')))

# Import necessary components from the bot
from main import NexusAI, setup_directories, setup_logging
from config.settings import BOT_PREFIX, DEFAULT_INTENTS, LOG_LEVEL, DATA_DIR, LOG_DIR, DATABASE_URL
from src.core.database_manager import DatabaseManager
from src.data.models import Base, UserProfile, GuildProfile, Interaction, ConversationContext
from src.ai_engine.gemini_integrator import GeminiIntegrator

# Suppress logging during tests to keep output clean unless debugging
logging.getLogger().setLevel(logging.CRITICAL)
logging.getLogger('discord').setLevel(logging.CRITICAL)
logging.getLogger('sqlalchemy').setLevel(logging.CRITICAL)
logging.getLogger('src').setLevel(logging.CRITICAL)

@pytest.fixture(scope="session", autouse=True)
def event_loop():
    """Create an instance of the default event loop for the session."""
    loop = asyncio.get_event_loop_policy().new_event_loop()
    yield loop
    loop.close()

@pytest.fixture(scope="function")
async def bot_instance():
    """Fixture to provide a bot instance for testing with mocked external services."""
    # Define temporary directories for testing
    test_data_dir = './test_data_integration'
    test_log_dir = './test_logs_integration'

    # Ensure clean slate for directories
    if os.path.exists(test_data_dir):
        shutil.rmtree(test_data_dir)
    if os.path.exists(test_log_dir):
        shutil.rmtree(test_log_dir)

    # Patch settings for testing
    with patch('config.settings.DATABASE_URL', 'sqlite:///:memory:'):
        with patch('config.settings.LOG_LEVEL', 'CRITICAL'):
            with patch('config.settings.DATA_DIR', test_data_dir):
                with patch('config.settings.LOG_DIR', test_log_dir):
                    # Ensure test directories exist
                    setup_directories()
                    setup_logging()

                    # Initialize DatabaseManager and create tables in in-memory DB
                    db_manager = DatabaseManager()
                    db_manager.create_all_tables()

                    # Mock the GeminiIntegrator singleton instance
                    mock_gemini_integrator = AsyncMock(spec=GeminiIntegrator)
                    mock_gemini_integrator.send_text_prompt.return_value = ("Mocked AI response", None)
                    mock_gemini_integrator.send_chat_message.return_value = ("Mocked chat response", None)
                    
                    # Patch the _instance attribute of the singleton class
                    with patch.object(GeminiIntegrator, '_instance', mock_gemini_integrator):
                        # Create a bot instance
                        bot = NexusAI()
                        
                        # Manually call setup_hook to load cogs
                        await bot.setup_hook()

                        yield bot
                    
                    # Clean up test directories after the test function
                    if os.path.exists(test_data_dir):
                        shutil.rmtree(test_data_dir)
                    if os.path.exists(test_log_dir):
                        shutil.rmtree(test_log_dir)

@pytest.fixture
def mock_context(bot_instance: NexusAI):
    """Fixture to create a mock Discord context."""
    ctx = AsyncMock(spec=commands.Context)
    ctx.bot = bot_instance
    
    # Mock author (Member)
    ctx.author = MagicMock(spec=discord.Member)
    ctx.author.id = 123456789
    ctx.author.name = "test_user"
    ctx.author.global_name = "Test User"
    ctx.author.display_name = "Test User Display"
    
    # Mock guild
    ctx.guild = MagicMock(spec=discord.Guild)
    ctx.guild.id = 987654321
    ctx.guild.name = "Test Guild"
    
    # Mock channel
    ctx.channel = MagicMock(spec=discord.TextChannel)
    ctx.channel.id = 1122334455
    ctx.channel.name = "test-channel"
    
    # Mock message
    ctx.message = MagicMock(spec=discord.Message)
    ctx.message.content = ""
    ctx.message.author = ctx.author
    ctx.message.guild = ctx.guild
    ctx.message.channel = ctx.channel
    
    # Mock context methods
    ctx.send = AsyncMock()
    ctx.reply = AsyncMock()
    ctx.typing = MagicMock()
    ctx.typing.return_value.__aenter__ = AsyncMock(return_value=None)
    ctx.typing.return_value.__aexit__ = AsyncMock(return_value=None)
    
    return ctx

class TestDiscordInteractions:
    @pytest.mark.asyncio
    async def test_ping_command(self, bot_instance: NexusAI, mock_context: AsyncMock):
        """Test the !ping command."""
        mock_context.message.content = f"{BOT_PREFIX}ping"
        
        command = bot_instance.get_command("ping")
        assert command is not None, "Ping command not found"
        
        await command(mock_context)
        
        mock_context.send.assert_called_once()
        sent_message = mock_context.send.call_args[0][0]
        assert "Pong!" in sent_message
        assert "ms" in sent_message
        
        db_manager = DatabaseManager()
        with db_manager.get_session() as session:
            interaction = session.query(Interaction).filter_by(user_id=mock_context.author.id, command_name="ping").first()
            assert interaction is not None
            assert interaction.prompt == f"{BOT_PREFIX}ping"
            assert "Pong!" in interaction.response_text
            assert interaction.success is True
            assert interaction.guild_id == mock_context.guild.id
            assert interaction.channel_id == mock_context.channel.id

    @pytest.mark.asyncio
    async def test_info_command(self, bot_instance: NexusAI, mock_context: AsyncMock):
        """Test the !info command."""
        mock_context.message.content = f"{BOT_PREFIX}info"
        
        command = bot_instance.get_command("info")
        assert command is not None, "Info command not found"
        
        # Mock bot attributes needed for info command
        bot_instance.user = MagicMock(spec=discord.ClientUser)
        bot_instance.user.name = "NexusA.I."
        bot_instance.user.id = 12345
        bot_instance.guilds = [MagicMock(spec=discord.Guild) for _ in range(3)] # Simulate 3 guilds
        
        await command(mock_context)
        
        mock_context.send.assert_called_once()
        sent_embed = mock_context.send.call_args[1]['embed']
        assert isinstance(sent_embed, discord.Embed)
        assert "NexusA.I. Bot Info" in sent_embed.title
        assert "Uptime" in sent_embed.description
        assert "Latency" in sent_embed.description
        assert "Servers" in sent_embed.description
        assert "Commands" in sent_embed.description
        
        db_manager = DatabaseManager()
        with db_manager.get_session() as session:
            interaction = session.query(Interaction).filter_by(user_id=mock_context.author.id, command_name="info").first()
            assert interaction is not None
            assert interaction.prompt == f"{BOT_PREFIX}info"
            assert "NexusA.I. Bot Info" in interaction.response_text # Check for embed title in response_text
            assert interaction.success is True

    @pytest.mark.asyncio
    async def test_ask_command(self, bot_instance: NexusAI, mock_context: AsyncMock):
        """Test the !ask command with a mocked AI response."""
        query = "What is the capital of France?"
        mock_context.message.content = f"{BOT_PREFIX}ask {query}"
        
        command = bot_instance.get_command("ask")
        assert command is not None, "Ask command not found"
        
        mock_gemini_integrator = GeminiIntegrator() # This will return the patched mock
        mock_gemini_integrator.send_text_prompt.return_value = ("Paris is the capital of France.", None)
        
        await command(mock_context, query=query)
        
        mock_context.send.assert_called_once_with("Paris is the capital of France.")
        mock_gemini_integrator.send_text_prompt.assert_called_once_with(query, history=None)
        
        db_manager = DatabaseManager()
        with db_manager.get_session() as session:
            interaction = session.query(Interaction).filter_by(user_id=mock_context.author.id, command_name="ask").first()
            assert interaction is not None
            assert interaction.prompt == query
            assert interaction.response_text == "Paris is the capital of France."
            assert interaction.success is True
            
            user_profile = session.query(UserProfile).filter_by(discord_id=mock_context.author.id).first()
            assert user_profile is not None
            assert user_profile.username == mock_context.author.name
            assert user_profile.global_name == mock_context.author.global_name
            assert user_profile.display_name == mock_context.author.display_name

    @pytest.mark.asyncio
    async def test_code_command(self, bot_instance: NexusAI, mock_context: AsyncMock):
        """Test the !code command with a mocked AI response."""
        query = "Generate a Python function for Fibonacci sequence."
        mock_context.message.content = f"{BOT_PREFIX}code {query}"
        
        command = bot_instance.get_command("code")
        assert command is not None, "Code command not found"
        
        mock_gemini_integrator = GeminiIntegrator() # This will return the patched mock
        mock_gemini_integrator.send_text_prompt.return_value = ("```python\ndef fibonacci(n):\n    a, b = 0, 1\n    for _ in range(n):\n        yield a\n        a, b = b, a + b\n```", None)
        
        await command(mock_context, query=query)
        
        mock_context.send.assert_called_once()
        sent_message = mock_context.send.call_args[0][0]
        assert "```python" in sent_message
        assert "def fibonacci(n):" in sent_message
        
        db_manager = DatabaseManager()
        with db_manager.get_session() as session:
            interaction = session.query(Interaction).filter_by(user_id=mock_context.author.id, command_name="code").first()
            assert interaction is not None
            assert interaction.prompt == query
            assert "def fibonacci(n):" in interaction.response_text
            assert interaction.success is True

    @pytest.mark.asyncio
    async def test_command_not_found(self, bot_instance: NexusAI, mock_context: AsyncMock):
        """Test handling of a command that does not exist."""
        mock_context.message.content = f"{BOT_PREFIX}nonexistentcommand"
        
        # Manually call the bot's error handler for CommandNotFound
        # The on_command_error handler in main.py logs a warning but does not send a message.
        error = commands.CommandNotFound(f"Command '{mock_context.message.content}' is not found.")
        await bot_instance.on_command_error(mock_context, error)
        
        # Assert that ctx.send was NOT called, as per main.py's on_command_error
        mock_context.send.assert_not_called()
        
        # Verify that no interaction is recorded for a command not found (as per AICommands logic)
        db_manager = DatabaseManager()
        with db_manager.get_session() as session:
            interaction = session.query(Interaction).filter_by(user_id=mock_context.author.id, command_name="nonexistentcommand").first()
            assert interaction is None

    @pytest.mark.asyncio
    async def test_ai_command_api_error(self, bot_instance: NexusAI, mock_context: AsyncMock):
        """Test !ask command when Gemini API returns an error."""
        query = "Tell me something."
        mock_context.message.content = f"{BOT_PREFIX}ask {query}"
        
        command = bot_instance.get_command("ask")
        assert command is not None
        
        mock_gemini_integrator = GeminiIntegrator()
        mock_gemini_integrator.send_text_prompt.return_value = (None, "API Error: Something went wrong.")
        
        await command(mock_context, query=query)
        
        mock_context.send.assert_called_once_with("An error occurred while processing your request: API Error: Something went wrong.")
        
        db_manager = DatabaseManager()
        with db_manager.get_session() as session:
            interaction = session.query(Interaction).filter_by(user_id=mock_context.author.id, command_name="ask").first()
            assert interaction is not None
            assert interaction.prompt == query
            assert interaction.response_text is None
            assert "API Error" in interaction.error_message
            assert interaction.success is False

    @pytest.mark.asyncio
    async def test_ai_command_content_blocked(self, bot_instance: NexusAI, mock_context: AsyncMock):
        """Test !ask command when Gemini API blocks content."""
        query = "Tell me something inappropriate."
        mock_context.message.content = f"{BOT_PREFIX}ask {query}"
        
        command = bot_instance.get_command("ask")
        assert command is not None
        
        mock_gemini_integrator = GeminiIntegrator()
        mock_gemini_integrator.send_text_prompt.return_value = (None, "Content blocked: The response was blocked due to safety concerns.")
        
        await command(mock_context, query=query)
        
        mock_context.send.assert_called_once_with("An error occurred while processing your request: Content blocked: The response was blocked due to safety concerns.")
        
        db_manager = DatabaseManager()
        with db_manager.get_session() as session:
            interaction = session.query(Interaction).filter_by(user_id=mock_context.author.id, command_name="ask").first()
            assert interaction is not None
            assert interaction.prompt == query
            assert interaction.response_text is None
            assert "Content blocked" in interaction.error_message
            assert interaction.success is False

    @pytest.mark.asyncio
    async def test_user_profile_creation_on_first_interaction(self, bot_instance: NexusAI, mock_context: AsyncMock):
        """Verify that a UserProfile is created on the first interaction."""
        db_manager = DatabaseManager()
        with db_manager.get_session() as session:
            session.query(UserProfile).filter_by(discord_id=mock_context.author.id).delete()
            session.commit()

        query = "Hello bot!"
        mock_context.message.content = f"{BOT_PREFIX}ask {query}"
        
        command = bot_instance.get_command("ask")
        mock_gemini_integrator = GeminiIntegrator()
        mock_gemini_integrator.send_text_prompt.return_value = ("Hello there!", None)
        
        await command(mock_context, query=query)
        
        with db_manager.get_session() as session:
            user_profile = session.query(UserProfile).filter_by(discord_id=mock_context.author.id).first()
            assert user_profile is not None
            assert user_profile.discord_id == mock_context.author.id
            assert user_profile.username == mock_context.author.name
            assert user_profile.global_name == mock_context.author.global_name
            assert user_profile.display_name == mock_context.author.display_name
            assert user_profile.is_bot_owner is False
            assert user_profile.is_admin is False

    @pytest.mark.asyncio
    async def test_user_profile_update_on_subsequent_interaction(self, bot_instance: NexusAI, mock_context: AsyncMock):
        """Verify that an existing UserProfile is updated on subsequent interactions."""
        db_manager = DatabaseManager()
        with db_manager.get_session() as session:
            existing_user = UserProfile(
                discord_id=mock_context.author.id,
                username="old_username",
                global_name="Old Global Name",
                display_name="Old Display Name",
                is_bot_owner=False,
                is_admin=False
            )
            session.add(existing_user)
            session.commit()
        
        # Simulate a change in user's name/global_name/display_name
        mock_context.author.name = "new_username"
        mock_context.author.global_name = "New Global Name"
        mock_context.author.display_name = "New Display Name"

        query = "How are you?"
        mock_context.message.content = f"{BOT_PREFIX}ask {query}"
        
        command = bot_instance.get_command("ask")
        mock_gemini_integrator = GeminiIntegrator()
        mock_gemini_integrator.send_text_prompt.return_value = ("I'm good!", None)
        
        await command(mock_context, query=query)
        
        with db_manager.get_session() as session:
            user_profile = session.query(UserProfile).filter_by(discord_id=mock_context.author.id).first()
            assert user_profile is not None
            assert user_profile.username == "new_username"
            assert user_profile.global_name == "New Global Name"
            assert user_profile.display_name == "New Display Name"
            assert user_profile.is_bot_owner is False
            assert user_profile.is_admin is False

    @pytest.mark.asyncio
    async def test_guild_profile_creation_on_first_interaction(self, bot_instance: NexusAI, mock_context: AsyncMock):
        """Verify that a GuildProfile is created on the first interaction."""
        db_manager = DatabaseManager()
        with db_manager.get_session() as session:
            session.query(GuildProfile).filter_by(discord_id=mock_context.guild.id).delete()
            session.commit()

        query = "Hello bot in guild!"
        mock_context.message.content = f"{BOT_PREFIX}ask {query}"
        
        command = bot_instance.get_command("ask")
        mock_gemini_integrator = GeminiIntegrator()
        mock_gemini_integrator.send_text_prompt.return_value = ("Hello from guild!", None)
        
        await command(mock_context, query=query)
        
        with db_manager.get_session() as session:
            guild_profile = session.query(GuildProfile).filter_by(discord_id=mock_context.guild.id).first()
            assert guild_profile is not None
            assert guild_profile.discord_id == mock_context.guild.id
            assert guild_profile.name == mock_context.guild.name
            assert guild_profile.custom_prefix == BOT_PREFIX

    @pytest.mark.asyncio
    async def test_guild_profile_update_on_subsequent_interaction(self, bot_instance: NexusAI, mock_context: AsyncMock):
        """Verify that an existing GuildProfile is updated on subsequent interactions."""
        db_manager = DatabaseManager()
        with db_manager.get_session() as session:
            existing_guild = GuildProfile(
                discord_id=mock_context.guild.id,
                name="Old Guild Name",
                custom_prefix="?"
            )
            session.add(existing_guild)
            session.commit()
        
        # Simulate a change in guild's name
        mock_context.guild.name = "New Test Guild Name"

        query = "How is this guild?"
        mock_context.message.content = f"{BOT_PREFIX}ask {query}"
        
        command = bot_instance.get_command("ask")
        mock_gemini_integrator = GeminiIntegrator()
        mock_gemini_integrator.send_text_prompt.return_value = ("This guild is great!", None)
        
        await command(mock_context, query=query)
        
        with db_manager.get_session() as session:
            guild_profile = session.query(GuildProfile).filter_by(discord_id=mock_context.guild.id).first()
            assert guild_profile is not None
            assert guild_profile.name == "New Test Guild Name"
            assert guild_profile.custom_prefix == "?" # Should not change unless a command for it is used