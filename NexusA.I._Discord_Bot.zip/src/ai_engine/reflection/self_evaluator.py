import logging
import json
from typing import Dict, Any, Optional

from config.settings import LOG_LEVEL
from src.ai_engine.gemini_integrator import GeminiIntegrator
from src.core.database_manager import DatabaseManager

class SelfEvaluator:
    """
    Module responsible pela autoavaliação das respostas e comportamentos do bot.
    Ele utiliza a API Google Gemini para avaliar criticamente a qualidade, relevância
    e aderência às instruções da saída gerada pelo bot.
    Implementa o padrão singleton para garantir um mecanismo de avaliação único e consistente.
    """
    _instance = None
    _initialized = False

    def __new__(cls, *args, **kwargs):
        """
        Implementa o padrão singleton para garantir que apenas uma instância de
        SelfEvaluator exista.
        """
        if cls._instance is None:
            cls._instance = super(SelfEvaluator, cls).__new__(cls)
        return cls._instance

    def __init__(self):
        """
        Inicializa o SelfEvaluator, configurando o logger e os integradores de IA necessários.
        Esta lógica de construtor é executada apenas uma vez devido ao padrão singleton.
        """
        if not self._initialized:
            self.logger = logging.getLogger(__name__)
            self.logger.setLevel(LOG_LEVEL)
            self.gemini_integrator = GeminiIntegrator()
            self.db_manager = DatabaseManager() # Inicializado para uso futuro potencial ou logging de avaliações
            self._initialized = True
            self.logger.info("SelfEvaluator inicializado.")

    async def evaluate_response(self, 
                                original_prompt: str, 
                                bot_response: str, 
                                evaluation_context: Optional[Dict[str, Any]] = None) -> Dict[str, Any]:
        """
        Avalia a resposta de um bot com base no prompt original e em um contexto opcional.
        Ele constrói um prompt para o modelo Gemini atuar como um avaliador e
        analisa sua saída estruturada.

        Args:
            original_prompt (str): O prompt original dado ao bot.
            bot_response (str): A resposta gerada pelo bot.
            evaluation_context (Optional[Dict[str, Any]]): Contexto adicional ou critérios específicos
                                                            para avaliação.
                                                            Exemplo: {"goal": "gerar código preciso", "safety_check": True}

        Returns:
            Dict[str, Any]: Um dicionário contendo os resultados da avaliação,
                            por exemplo, pontuações, justificativas, avaliação geral.
                            Retorna um dicionário de erro se a avaliação falhar.
        """
        self.logger.debug(f"Iniciando autoavaliação para o prompt: '{original_prompt[:50]}...'")
        self.logger.debug(f"Resposta do bot a ser avaliada: '{bot_response[:50]}...'")

        # Critérios de avaliação padrão e instruções para o avaliador de IA
        criteria_prompt = """
        Você é um assistente de IA especialista encarregado de avaliar criticamente a qualidade da resposta de outro IA.
        Seu objetivo é fornecer uma avaliação justa, objetiva e construtiva.

        Prompt Original do Usuário:
        ```
        {original_prompt}
        ```

        Resposta do IA a ser Avaliada:
        ```
        {bot_response}
        ```

        Por favor, avalie a resposta do IA com base nos seguintes critérios:
        1.  **Relevância (Pontuação 1-5):** Quão bem a resposta aborda diretamente o prompt do usuário? (1=Não relevante, 5=Altamente relevante)
        2.  **Precisão (Pontuação 1-5):** A informação fornecida é factualmente correta e livre de erros? (1=Incorreta, 5=Altamente precisa)
        3.  **Completude (Pontuação 1-5):** A resposta responde completamente ao prompt ou fornece detalhes suficientes? (1=Incompleta, 5=Abrangente)
        4.  **Clareza e Coerência (Pontuação 1-5):** A resposta é fácil de entender, bem estruturada e logicamente coerente? (1=Confusa, 5=Muito clara)
        5.  **Segurança e Ética (Pontuação 1-5):** A resposta evita conteúdo prejudicial, tendencioso ou inapropriado? (1=Insegura/Antiética, 5=Completamente segura/ética)
        6.  **Aderência às Instruções (Pontuação 1-5):** Se o prompt continha instruções específicas (ex: "gerar código", "resumir em 3 frases", "usar um formato específico"), quão bem o IA as seguiu? (1=Ignorou instruções, 5=Seguiu perfeitamente)

        Forneça uma pontuação para cada critério (1-5) e uma breve justificativa para cada pontuação.
        Em seguida, forneça uma avaliação geral e sugestões concretas de como o IA poderia melhorar sua resposta.

        Formate sua saída ESTRITAMENTE como um objeto JSON. Não inclua nenhum outro texto fora do JSON.
        O objeto JSON deve ter a seguinte estrutura:
        ```json
        {{
            "evaluation": {{
                "relevance": {{"score": int, "justification": "string"}},
                "accuracy": {{"score": int, "justification": "string"}},
                "completeness": {{"score": int, "justification": "string"}},
                "clarity_coherence": {{"score": int, "justification": "string"}},
                "safety_ethics": {{"score": int, "justification": "string"}},
                "adherence_to_instructions": {{"score": int, "justification": "string"}}
            }},
            "overall_assessment": "string",
            "suggestions_for_improvement": "string"
        }}
        ```
        """

        # Incorporar contexto adicional, se fornecido
        if evaluation_context:
            # Esta parte pode ser expandida para adicionar dinamicamente mais critérios específicos
            # ou modificar o prompt com base no evaluation_context.
            # Por enquanto, apenas vamos logar.
            self.logger.debug(f"Contexto de avaliação fornecido: {evaluation_context}")
            if "goal" in evaluation_context:
                criteria_prompt += f"\n\nObjetivo específico para esta interação: {evaluation_context['goal']}"

        full_evaluation_prompt = criteria_prompt.format(
            original_prompt=original_prompt,
            bot_response=bot_response
        )

        try:
            # Enviar o prompt de avaliação para o modelo Gemini
            evaluation_raw_response, error_message = await self.gemini_integrator.send_text_prompt(
                prompt=full_evaluation_prompt,
                history=[] # Nenhuma história é necessária para um prompt de avaliação de turno único
            )

            if error_message:
                self.logger.error(f"A avaliação do Gemini falhou: {error_message}")
                return {"status": "error", "message": f"A avaliação da IA falhou: {error_message}"}

            if not evaluation_raw_response:
                self.logger.warning("A avaliação do Gemini retornou uma resposta vazia.")
                return {"status": "error", "message": "A avaliação da IA retornou uma resposta vazia."}

            # Tentar analisar a resposta JSON
            try:
                evaluation_result = json.loads(evaluation_raw_response)
                self.logger.info("Autoavaliação concluída com sucesso.")
                self.logger.debug(f"Resultado da avaliação: {json.dumps(evaluation_result, indent=2)}")
                evaluation_result["status"] = "success"
                return evaluation_result
            except json.JSONDecodeError as e:
                self.logger.error(f"Falha ao analisar JSON da avaliação do Gemini: {e}. Resposta bruta: {evaluation_raw_response}")
                return {"status": "error", "message": f"Falha ao analisar a resposta de avaliação da IA: {e}", "raw_response": evaluation_raw_response}

        except Exception as e:
            self.logger.exception(f"Ocorreu um erro inesperado durante a autoavaliação: {e}")
            return {"status": "error", "message": f"Ocorreu um erro inesperado durante a avaliação: {e}"}