import logging
import json
from typing import Dict, Any, Optional, Literal

from config.settings import LOG_LEVEL
from src.core.database_manager import DatabaseManager
from src.data.models import Interaction, UserProfile, KnowledgeNode, KnowledgeEdge
from src.ai_engine.gemini_integrator import GeminiIntegrator
from src.ai_engine.reflection.self_evaluator import SelfEvaluator
from src.ai_engine.knowledge_graph.graph_builder import GraphBuilder
from src.ai_engine.knowledge_graph.graph_query import GraphQuery
from sqlalchemy.exc import SQLAlchemyError

class FeedbackLoop:
    """
    Módulo para integrar feedback (interno/externo) para refinar o comportamento da IA.
    Processa feedback para identificar áreas de melhoria e acionar mecanismos de adaptação.
    Implementa o padrão singleton para garantir uma única instância.
    """
    _instance = None
    _initialized = False

    def __new__(cls, *args, **kwargs):
        """
        Implementa o padrão singleton para garantir que apenas uma instância de
        FeedbackLoop exista.
        """
        if cls._instance is None:
            cls._instance = super(FeedbackLoop, cls).__new__(cls)
        return cls._instance

    def __init__(self):
        """
        Inicializa o FeedbackLoop, configurando o logger e os integradores necessários.
        Esta lógica de construtor é executada apenas uma vez devido ao padrão singleton.
        """
        if not self._initialized:
            self.logger = logging.getLogger(__name__)
            self.logger.setLevel(LOG_LEVEL)
            self.db_manager = DatabaseManager()
            self.gemini_integrator = GeminiIntegrator()
            self.self_evaluator = SelfEvaluator()
            self.graph_builder = GraphBuilder()
            self.graph_query = GraphQuery()
            self._initialized = True
            self.logger.info("FeedbackLoop initialized.")

    async def process_feedback(self,
                               interaction_id: int,
                               feedback_type: Literal["user_rating", "correction", "internal_evaluation"],
                               feedback_data: Dict[str, Any],
                               user_id: Optional[int] = None,
                               channel_id: Optional[int] = None) -> bool:
        """
        Processa feedback recebido, seja de usuários ou de avaliações internas.
        Atualiza o registro da interação e aciona mecanismos de refinamento.

        Args:
            interaction_id (int): O ID da interação à qual o feedback se refere.
            feedback_type (Literal): O tipo de feedback (e.g., "user_rating", "correction", "internal_evaluation").
            feedback_data (Dict[str, Any]): Dados específicos do feedback (e.g., {"rating": 5}, {"corrected_response": "..."}).
            user_id (Optional[int]): O ID do usuário que forneceu o feedback (se aplicável).
            channel_id (Optional[int]): O ID do canal onde a interação ocorreu (se aplicável).

        Returns:
            bool: True se o feedback foi processado com sucesso, False caso contrário.
        """
        self.logger.info(f"Processing feedback for interaction ID {interaction_id} of type '{feedback_type}'.")
        session = self.db_manager.get_session()
        try:
            interaction = session.query(Interaction).filter_by(id=interaction_id).first()
            if not interaction:
                self.logger.warning(f"Interaction with ID {interaction_id} not found for feedback.")
                session.close()
                return False

            # Update interaction based on feedback type
            if feedback_type == "user_rating":
                rating = feedback_data.get("rating")
                if rating is not None:
                    # ASSUMPTION: Interaction model has 'user_rating' (Float/Integer) and 'feedback_notes' (Text) fields.
                    if hasattr(interaction, 'user_rating'):
                        interaction.user_rating = rating
                    if hasattr(interaction, 'feedback_notes'):
                        interaction.feedback_notes = feedback_data.get("notes")
                    # Simple heuristic for success based on rating
                    interaction.success = (rating >= 3)
                    self.logger.debug(f"User rating {rating} applied to interaction {interaction_id}.")
                    await self._adapt_from_user_feedback(session, interaction, rating, feedback_data.get("notes"))

            elif feedback_type == "correction":
                corrected_response = feedback_data.get("corrected_response")
                correction_notes = feedback_data.get("notes")
                if corrected_response:
                    # ASSUMPTION: Interaction model has 'corrected_response' (Text) and 'feedback_notes' (Text) fields.
                    if hasattr(interaction, 'corrected_response'):
                        interaction.corrected_response = corrected_response
                    if hasattr(interaction, 'feedback_notes'):
                        interaction.feedback_notes = correction_notes
                    # A correction implies the original was flawed, but now we have a "good" version
                    interaction.success = True
                    self.logger.debug(f"Correction applied to interaction {interaction_id}.")
                    await self._adapt_from_correction(session, interaction, corrected_response, correction_notes)

            elif feedback_type == "internal_evaluation":
                evaluation_results = feedback_data.get("evaluation_results")
                if evaluation_results:
                    # ASSUMPTION: Interaction model has 'internal_evaluation' (Text, storing JSON string) field.
                    if hasattr(interaction, 'internal_evaluation'):
                        interaction.internal_evaluation = json.dumps(evaluation_results)
                    # Example heuristic for success based on internal evaluation score
                    interaction.success = evaluation_results.get("overall_score", 0) >= 0.7
                    self.logger.debug(f"Internal evaluation applied to interaction {interaction_id}.")
                    await self._adapt_from_internal_evaluation(session, interaction, evaluation_results)

            session.add(interaction)
            session.commit()
            self.logger.info(f"Feedback for interaction {interaction_id} processed successfully.")
            return True

        except SQLAlchemyError as e:
            self.logger.error(f"Database error processing feedback for interaction {interaction_id}: {e}")
            session.rollback()
            return False
        except Exception as e:
            self.logger.error(f"Unexpected error processing feedback for interaction {interaction_id}: {e}")
            return False
        finally:
            session.close()

    async def _adapt_from_user_feedback(self, session, interaction: Interaction, rating: int, notes: Optional[str]):
        """
        Lógica de adaptação baseada em feedback de usuário (avaliação).
        Pode envolver ajustar o grafo de conhecimento ou registrar para revisão.
        """
        self.logger.debug(f"Adapting from user feedback for interaction {interaction.id} with rating {rating}.")
        # Exemplo: Se a avaliação for baixa, registrar para revisão humana ou acionar uma autoavaliação mais detalhada.
        if rating < 3:
            self.logger.warning(f"Baixa avaliação do usuário ({rating}) para a interação {interaction.id}. Prompt original: '{interaction.prompt}', Resposta do bot: '{interaction.response_text}'. Notas: {notes}")
            # Potencialmente acionar uma autoavaliação para esta interação específica
            if interaction.prompt and interaction.response_text:
                self_eval_results = await self.self_evaluator.evaluate_response(
                    original_prompt=interaction.prompt,
                    bot_response=interaction.response_text,
                    evaluation_context={"feedback_source": "user_rating", "user_rating": rating, "user_notes": notes}
                )
                self.logger.info(f"Autoavaliação acionada devido a baixa avaliação do usuário. Resultados: {self_eval_results}")
                # Atualizar a interação com os resultados da avaliação interna
                # ASSUMPTION: Interaction model has 'internal_evaluation' (Text, storing JSON string) field.
                if hasattr(interaction, 'internal_evaluation'):
                    interaction.internal_evaluation = json.dumps(self_eval_results)
                # Update success based on evaluation (e.g., if overall_score is present)
                if "overall_score" in self_eval_results:
                    interaction.success = self_eval_results["overall_score"] >= 0.7 # Exemplo de heurística
                session.add(interaction) # Adicionar à sessão, o commit ocorrerá em process_feedback

        # Se a avaliação for alta, reforçar o comportamento positivo (e.g., adicionar ao grafo de conhecimento se relevante)
        elif rating >= 4:
            self.logger.info(f"Alta avaliação do usuário ({rating}) para a interação {interaction.id}. Considerar reforçar o conhecimento.")
            # Exemplo: Se a resposta continha informações factuais, considerar adicionar/reforçar no KG
            # Isso exigiria NLP para extrair fatos, o que está além do escopo deste arquivo,
            # mas o placeholder mostra a intenção. Por enquanto, apenas registrar o feedback positivo.

    async def _adapt_from_correction(self, session, interaction: Interaction, corrected_response: str, notes: Optional[str]):
        """
        Lógica de adaptação baseada em uma correção explícita de um usuário/operador.
        Isso é um sinal forte de que a resposta original estava errada e deve ser usada
        para atualizar o conhecimento ou o comportamento do bot.
        """
        self.logger.debug(f"Adapting from correction for interaction {interaction.id}.")
        # Aqui, a corrected_response é o padrão ouro.
        # Podemos usá-la para atualizar o grafo de conhecimento ou treinar um modelo específico.

        # Exemplo: Usar Gemini para extrair conhecimento da resposta corrigida
        prompt_for_kg_update = (
            f"A resposta original do bot para o prompt '{interaction.prompt}' foi corrigida para '{corrected_response}'. "
            f"Extraia fatos, conceitos e relações chave desta correção que poderiam ser adicionados ao grafo de conhecimento "
            f"para melhorar futuras respostas. Formate como JSON: {{'nodes': [], 'edges': []}}."
        )
        kg_suggestion_json, error = await self.gemini_integrator.send_text_prompt(prompt_for_kg_update)

        if kg_suggestion_json and not error:
            try:
                kg_data = json.loads(kg_suggestion_json)
                nodes_to_add = kg_data.get("nodes", [])
                edges_to_add = kg_data.get("edges", [])

                for node_info in nodes_to_add:
                    label = node_info.get("label")
                    node_type = node_info.get("type", "concept")
                    description = node_info.get("description")
                    if label:
                        self.graph_builder.add_node(label, node_type, description)
                        self.logger.info(f"Adicionado/atualizado nó '{label}' a partir da correção.")

                for edge_info in edges_to_add:
                    source_label = edge_info.get("source")
                    target_label = edge_info.get("target")
                    relationship_type = edge_info.get("relationship")
                    properties = edge_info.get("properties", {})

                    source_node = self.graph_builder.get_node_by_label(source_label)
                    target_node = self.graph_builder.get_node_by_label(target_label)

                    if source_node and target_node and relationship_type:
                        self.graph_builder.add_edge(source_node, target_node, relationship_type, properties)
                        self.logger.info(f"Adicionada/atualizada aresta '{source_label} -[{relationship_type}]-> {target_label}' a partir da correção.")
            except json.JSONDecodeError:
                self.logger.error(f"Falha ao analisar o JSON de sugestão do KG do Gemini para correção: {kg_suggestion_json}")
            except Exception as e:
                self.logger.error(f"Erro ao processar a sugestão do KG do Gemini para correção: {e}")
        else:
            self.logger.warning(f"Gemini falhou em fornecer sugestão de KG para correção ou retornou um erro: {error}")

    async def _adapt_from_internal_evaluation(self, session, interaction: Interaction, evaluation_results: Dict[str, Any]):
        """
        Lógica de adaptação baseada em uma avaliação interna do próprio bot.
        """
        self.logger.debug(f"Adapting from internal evaluation for interaction {interaction.id}.")
        overall_score = evaluation_results.get("overall_score")
        feedback_summary = evaluation_results.get("feedback_summary")
        areas_for_improvement = evaluation_results.get("areas_for_improvement", [])

        if overall_score is not None and overall_score < 0.7: # Exemplo de limiar para "precisa melhorar"
            self.logger.warning(f"Avaliação interna indica baixa pontuação ({overall_score}) para a interação {interaction.id}. Resumo: {feedback_summary}")
            # Usar as áreas de melhoria para guiar ações futuras
            for area in areas_for_improvement:
                self.logger.info(f"Área de melhoria identificada: {area}")
                # Isso poderia acionar ações específicas, por exemplo:
                # - Se "precisão factual" for um problema, consultar o grafo de conhecimento para informações relevantes.
                # - Se "coerência" for um problema, revisar o uso da memória de curto prazo.
                # - Se "aderência ao prompt" for um problema, refinar a engenharia de prompt para o Gemini.

                # Exemplo: Se a precisão factual for mencionada, tentar consultar o KG
                if "factual accuracy" in area.lower() and interaction.prompt:
                    kg_search_prompt = f"A resposta do bot para '{interaction.prompt}' foi avaliada como tendo problemas de precisão factual. Quais termos ou conceitos chave podem ser pesquisados no grafo de conhecimento para verificar a informação?"
                    search_terms_json, error = await self.gemini_integrator.send_text_prompt(kg_search_prompt)
                    if search_terms_json and not error:
                        try:
                            search_terms_data = json.loads(search_terms_json)
                            search_terms = search_terms_data.get("terms", [])
                            for term in search_terms:
                                nodes = self.graph_query.find_nodes(label=term)
                                if nodes:
                                    self.logger.info(f"Nós relevantes encontrados para '{term}': {[n.label for n in nodes]}.")
                                    # Lógica adicional para comparar informações do KG com a resposta do bot
                                else:
                                    self.logger.info(f"Nenhum nó encontrado para '{term}'. Pode ser uma lacuna de conhecimento.")
                        except json.JSONDecodeError:
                            self.logger.error(f"Falha ao analisar o JSON de termos de pesquisa do Gemini: {search_terms_json}")
                        except Exception as e:
                            self.logger.error(f"Erro ao processar termos de pesquisa do Gemini: {e}")

    async def request_self_evaluation(self, interaction_id: int) -> Optional[Dict[str, Any]]:
        """
        Solicita uma autoavaliação para uma interação específica.
        Útil para feedback interno proativo ou quando o feedback externo é ambíguo.

        Args:
            interaction_id (int): O ID da interação a ser avaliada.

        Returns:
            Optional[Dict[str, Any]]: Os resultados da avaliação ou None se a interação não for encontrada.
        """
        self.logger.info(f"Solicitando autoavaliação para a interação ID {interaction_id}.")
        session = self.db_manager.get_session()
        try:
            interaction = session.query(Interaction).filter_by(id=interaction_id).first()
            if not interaction:
                self.logger.warning(f"Interação com ID {interaction_id} não encontrada para autoavaliação.")
                return None

            if not interaction.prompt or not interaction.response_text:
                self.logger.warning(f"Interação {interaction_id} sem prompt ou resposta, não pode autoavaliar.")
                return None

            evaluation_results = await self.self_evaluator.evaluate_response(
                original_prompt=interaction.prompt,
                bot_response=interaction.response_text,
                evaluation_context={"feedback_source": "proactive_internal_request"}
            )

            if evaluation_results:
                # Armazenar os resultados da avaliação interna de volta na interação
                # ASSUMPTION: Interaction model has 'internal_evaluation' (Text, storing JSON string) field.
                if hasattr(interaction, 'internal_evaluation'):
                    interaction.internal_evaluation = json.dumps(evaluation_results)
                # Atualizar o sucesso com base na avaliação (e.g., se overall_score estiver presente)
                if "overall_score" in evaluation_results:
                    interaction.success = evaluation_results["overall_score"] >= 0.7 # Exemplo de limiar
                session.add(interaction)
                session.commit()
                self.logger.info(f"Autoavaliação para a interação {interaction_id} concluída e armazenada.")
                return evaluation_results
            else:
                self.logger.warning(f"Autoavaliação para a interação {interaction_id} não retornou resultados.")
                return None

        except SQLAlchemyError as e:
            self.logger.error(f"Erro de banco de dados durante a solicitação de autoavaliação para a interação {interaction_id}: {e}")
            session.rollback()
            return None
        except Exception as e:
            self.logger.error(f"Erro inesperado durante a solicitação de autoavaliação para a interação {interaction_id}: {e}")
            return None
        finally:
            session.close()