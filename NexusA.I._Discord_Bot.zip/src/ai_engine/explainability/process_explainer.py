import logging
import json
from typing import Optional, Dict, Any, List
from datetime import datetime

from config.settings import LOG_LEVEL
from src.core.database_manager import DatabaseManager
from src.data.models import Interaction
from sqlalchemy.exc import SQLAlchemyError


class ProcessExplainer:
    """
    Módulo para registrar e fornecer explicações sobre os raciocínios e processos internos do bot.
    Ele permite que o bot registre os passos, decisões e informações utilizadas durante
    a execução de uma tarefa, facilitando a explicabilidade e a depuração.
    Implementa o padrão singleton para garantir uma única instância.
    """
    _instance = None

    def __new__(cls, *args, **kwargs):
        """
        Implementa o padrão singleton para garantir que apenas uma instância de
        ProcessExplainer exista.
        """
        if cls._instance is None:
            cls._instance = super(ProcessExplainer, cls).__new__(cls)
        return cls._instance

    def __init__(self):
        """
        Inicializa o ProcessExplainer, configurando o logger e o gerenciador de banco de dados.
        Esta lógica de construtor é executada apenas uma vez devido ao padrão singleton.
        """
        if not hasattr(self, '_initialized'):
            self.logger = logging.getLogger(__name__)
            self.logger.setLevel(LOG_LEVEL)
            self.db_manager = DatabaseManager()
            self.logger.info("ProcessExplainer initialized.")
            self._initialized = True

    def record_explanation(self,
                           interaction_id: int,
                           explanation_type: str,
                           details: Dict[str, Any],
                           step_name: Optional[str] = None,
                           agent_role: Optional[str] = None) -> bool:
        """
        Registra uma entrada de explicação para uma interação específica.
        As explicações são armazenadas no campo 'internal_process_log' da tabela Interaction
        como uma lista JSON de objetos.

        Args:
            interaction_id (int): O ID da interação à qual esta explicação se refere.
            explanation_type (str): O tipo de explicação (e.g., "decision_making", "knowledge_retrieval", "response_generation").
            details (Dict[str, Any]): Um dicionário contendo os detalhes específicos da explicação.
            step_name (Optional[str]): O nome do passo ou fase do processo (opcional).
            agent_role (Optional[str]): O papel do agente simulado envolvido (opcional).

        Returns:
            bool: True se a explicação foi registrada com sucesso, False caso contrário.
        """
        try:
            with self.db_manager.get_session() as session:
                interaction = session.query(Interaction).filter_by(id=interaction_id).first()

                if not interaction:
                    self.logger.warning(f"Interaction with ID {interaction_id} not found. Cannot record explanation.")
                    return False

                current_log = []
                if interaction.internal_process_log:
                    try:
                        current_log = json.loads(interaction.internal_process_log)
                        if not isinstance(current_log, list):
                            self.logger.warning(f"internal_process_log for interaction {interaction_id} is not a list. Resetting.")
                            current_log = []
                    except json.JSONDecodeError:
                        self.logger.error(f"Failed to decode internal_process_log for interaction {interaction_id}. Resetting.")
                        current_log = []

                explanation_entry = {
                    "timestamp": datetime.now().isoformat(),
                    "type": explanation_type,
                    "details": details
                }
                if step_name:
                    explanation_entry["step_name"] = step_name
                if agent_role:
                    explanation_entry["agent_role"] = agent_role

                current_log.append(explanation_entry)
                interaction.internal_process_log = json.dumps(current_log)
                session.add(interaction)
                session.commit()
                self.logger.debug(f"Explanation recorded for interaction {interaction_id}, type: {explanation_type}")
                return True
        except SQLAlchemyError as e:
            self.logger.error(f"Database error while recording explanation for interaction {interaction_id}: {e}")
            return False
        except Exception as e:
            self.logger.error(f"An unexpected error occurred while recording explanation for interaction {interaction_id}: {e}")
            return False

    def get_explanations(self, interaction_id: int, explanation_type: Optional[str] = None) -> List[Dict[str, Any]]:
        """
        Recupera as explicações registradas para uma interação específica, opcionalmente filtrando por tipo.

        Args:
            interaction_id (int): O ID da interação para a qual as explicações devem ser recuperadas.
            explanation_type (Optional[str]): Opcional. Se fornecido, apenas explicações deste tipo serão retornadas.

        Returns:
            List[Dict[str, Any]]: Uma lista de dicionários, onde cada dicionário representa uma entrada de explicação.
                                  Retorna uma lista vazia se nenhuma explicação for encontrada ou em caso de erro.
        """
        try:
            with self.db_manager.get_session() as session:
                interaction = session.query(Interaction).filter_by(id=interaction_id).first()

                if not interaction or not interaction.internal_process_log:
                    return []

                try:
                    all_explanations = json.loads(interaction.internal_process_log)
                    if not isinstance(all_explanations, list):
                        self.logger.warning(f"internal_process_log for interaction {interaction_id} is not a list. Returning empty.")
                        return []
                except json.JSONDecodeError:
                    self.logger.error(f"Failed to decode internal_process_log for interaction {interaction_id}. Returning empty.")
                    return []

                if explanation_type:
                    filtered_explanations = [
                        exp for exp in all_explanations
                        if exp.get("type") == explanation_type
                    ]
                    return filtered_explanations
                else:
                    return all_explanations
        except SQLAlchemyError as e:
            self.logger.error(f"Database error while retrieving explanations for interaction {interaction_id}: {e}")
            return []
        except Exception as e:
            self.logger.error(f"An unexpected error occurred while retrieving explanations for interaction {interaction_id}: {e}")
            return []

    def get_latest_explanation(self, interaction_id: int, explanation_type: Optional[str] = None) -> Optional[Dict[str, Any]]:
        """
        Recupera a explicação mais recente para uma interação específica, opcionalmente filtrando por tipo.

        Args:
            interaction_id (int): O ID da interação para a qual a explicação deve ser recuperada.
            explanation_type (Optional[str]): Opcional. Se fornecido, apenas a explicação mais recente deste tipo será retornada.

        Returns:
            Optional[Dict[str, Any]]: O dicionário da explicação mais recente, ou None se nenhuma for encontrada.
        """
        explanations = self.get_explanations(interaction_id, explanation_type)
        if explanations:
            # Explanations are appended, so the last one is the latest.
            return explanations[-1]
        return None