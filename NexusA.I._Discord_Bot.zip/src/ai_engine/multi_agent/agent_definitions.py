import logging
from typing import Dict, Any, Optional, List

from config.settings import LOG_LEVEL

class AgentDefinitions:
    """
    Manages the definitions and system prompts for various simulated AI agents.
    These definitions guide the behavior of the Google Gemini model when it adopts
    a specific role within the multi-agent architecture.
    Implements a singleton pattern to ensure a single point of truth for agent configurations.
    """
    _instance = None
    _initialized = False

    def __new__(cls, *args, **kwargs):
        """
        Implements the singleton pattern to ensure only one instance of
        AgentDefinitions exists.
        """
        if cls._instance is None:
            cls._instance = super(AgentDefinitions, cls).__new__(cls)
        return cls._instance

    def __init__(self):
        """
        Initializes the AgentDefinitions, setting up logging and populating
        the agent definitions. This constructor logic runs only once due to
        the singleton pattern.
        """
        if not self._initialized:
            self.logger = logging.getLogger(__name__)
            self.logger.setLevel(LOG_LEVEL)
            self.agents: Dict[str, Dict[str, str]] = {}
            self._initialize_agents()
            self.logger.info("AgentDefinitions initialized and agents loaded.")
            AgentDefinitions._initialized = True

    def _initialize_agents(self):
        """
        Populates the internal dictionary with predefined agent roles and their
        corresponding system prompts and descriptions.
        """
        self.agents = {
            "general_agent": {
                "description": "A versatile agent capable of handling general inquiries and conversational tasks.",
                "system_prompt": (
                    "You are a General Purpose AI Assistant named NexusA.I. Your role is to understand and respond to a wide range of user queries in a helpful, informative, and friendly manner. "
                    "You can engage in general conversation, answer factual questions, and provide creative content. "
                    "Maintain a polite and cooperative tone. If a query requires specialized knowledge, indicate that or suggest a more appropriate agent if applicable. "
                    "Always strive to provide comprehensive and accurate information."
                )
            },
            "planning_agent": {
                "description": "Specialized in breaking down complex problems into actionable, sequential steps.",
                "system_prompt": (
                    "You are a highly analytical Planning Agent. Your primary task is to take a high-level problem or request and decompose it into a detailed, step-by-step plan. "
                    "Each step should be clear, concise, and actionable. Focus on logical progression, dependencies, and potential sub-tasks. "
                    "Output the plan as a numbered list. Do not execute the plan, only generate it. "
                    "Consider what information or tools might be needed for each step. Be precise and avoid ambiguity."
                )
            },
            "code_agent": {
                "description": "Expert in generating, optimizing, and debugging code across various programming languages.",
                "system_prompt": (
                    "You are a Code Agent, an expert programmer. Your primary function is to generate code based on specifications, optimize existing code for performance or readability, and identify/fix bugs. "
                    "When generating code, provide explanations, usage examples, and consider best practices. "
                    "When optimizing or debugging, explain your reasoning and the specific changes made. "
                    "Always strive for clean, efficient, secure, and well-commented code. If a language is not specified, default to Python. "
                    "Present code within markdown code blocks. If you cannot provide a complete solution, explain why and suggest alternatives."
                )
            },
            "research_agent": {
                "description": "Proficient in gathering, synthesizing, and summarizing information from various sources.",
                "system_prompt": (
                    "You are a Research Agent. Your goal is to gather information, analyze data, and provide concise, accurate summaries on a given topic. "
                    "Identify key facts, relationships, and potential ambiguities. "
                    "Synthesize information from multiple perspectives if available. Do not generate creative content; focus purely on factual information retrieval and synthesis. "
                    "If you were to access external databases or the internet, what keywords or queries would you use to find the information? Present your findings clearly and logically."
                )
            },
            "synthesis_agent": {
                "description": "Responsible for combining disparate pieces of information into a coherent and comprehensive final response.",
                "system_prompt": (
                    "You are a Synthesis Agent. Your task is to take a collection of intermediate results or fragmented information and combine them into a single, coherent, and well-structured final answer. "
                    "Ensure the response directly addresses the original request, is easy to understand, and flows logically. "
                    "Eliminate redundancies, resolve inconsistencies, and ensure completeness. "
                    "The final output should be a polished, user-ready response that directly answers the initial query."
                )
            },
            "reflection_agent": {
                "description": "An agent specialized in self-evaluation and critical analysis of generated content or processes.",
                "system_prompt": (
                    "You are a Reflection Agent. Your purpose is to critically evaluate a given piece of content (e.g., a bot's response, a plan, or a code snippet) against a set of criteria or an original prompt. "
                    "Identify strengths, weaknesses, potential errors, and areas for improvement. "
                    "Provide constructive feedback and suggest concrete modifications. "
                    "Your evaluation should be objective, thorough, and insightful. Focus on accuracy, completeness, relevance, and adherence to instructions. "
                    "Output your evaluation in a structured format, highlighting key points."
                )
            }
        }

    def get_agent_definition(self, role: str) -> Optional[Dict[str, str]]:
        """
        Retrieves the definition (description and system prompt) for a specified agent role.

        Args:
            role (str): The identifier for the agent role (e.g., "code_agent", "research_agent").

        Returns:
            Optional[Dict[str, str]]: A dictionary containing the 'description' and 'system_prompt'
                                      for the agent, or None if the role is not found.
        """
        return self.agents.get(role)

    def get_all_agent_roles(self) -> List[str]:
        """
        Returns a list of all defined agent roles.
        """
        return list(self.agents.keys())

    def get_agent_system_prompt(self, role: str) -> Optional[str]:
        """
        Retrieves only the system prompt for a specified agent role.

        Args:
            role (str): The identifier for the agent role.

        Returns:
            Optional[str]: The system prompt string, or None if the role is not found.
        """
        definition = self.get_agent_definition(role)
        return definition.get("system_prompt") if definition else None

    def get_agent_description(self, role: str) -> Optional[str]:
        """
        Retrieves only the description for a specified agent role.

        Args:
            role (str): The identifier for the agent role.

        Returns:
            Optional[str]: The description string, or None if the role is not found.
        """
        definition = self.get_agent_definition(role)
        return definition.get("description") if definition else None