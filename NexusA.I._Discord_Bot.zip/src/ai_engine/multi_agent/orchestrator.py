import logging
from typing import Dict, List, Optional, Any
import json

from config.settings import LOG_LEVEL
from src.ai_engine.gemini_integrator import GeminiIntegrator
from src.ai_engine.context_memory.long_term_memory import LongTermMemory
from src.ai_engine.context_memory.short_term_memory import ShortTermMemory
from src.ai_engine.knowledge_graph.graph_builder import GraphBuilder
from src.ai_engine.knowledge_graph.graph_query import GraphQuery
from src.ai_engine.reflection.self_evaluator import SelfEvaluator
from src.ai_engine.reflection.feedback_loop import FeedbackLoop
from src.core.database_manager import DatabaseManager
from src.data.models import Interaction # To record orchestration steps/results

class Orchestrator:
    """
    Orchestrates the multi-agent simulation by directing tasks, coordinating
    internal 'agents' (simulated AI roles), and managing their interactions
    with memory, knowledge graph, and reflection modules.
    Implements a singleton pattern to ensure a single point of control for
    complex AI task execution.
    """
    _instance = None

    def __new__(cls, *args, **kwargs):
        """
        Implements the singleton pattern to ensure only one instance of
        Orchestrator exists.
        """
        if cls._instance is None:
            cls._instance = super(Orchestrator, cls).__new__(cls)
            cls._instance._initialized = False # Use a flag to prevent re-initialization
        return cls._instance

    def __init__(self):
        """
        Initializes the Orchestrator, setting up logging and instances of
        various AI engine components. This constructor logic runs only once
        due to the singleton pattern.
        """
        if self._initialized:
            return
        
        self.logger = logging.getLogger(__name__)
        self.logger.setLevel(LOG_LEVEL)

        self.gemini_integrator = GeminiIntegrator()
        self.short_term_memory = ShortTermMemory()
        self.long_term_memory = LongTermMemory()
        self.graph_builder = GraphBuilder() # Potentially used by agents to update graph
        self.graph_query = GraphQuery()
        self.self_evaluator = SelfEvaluator()
        self.feedback_loop = FeedbackLoop()
        self.db_manager = DatabaseManager() # For recording detailed interaction steps

        self.logger.info("Orchestrator initialized.")
        self._initialized = True

    async def orchestrate_task(self, 
                               task_description: str, 
                               user_id: int, 
                               channel_id: int,
                               interaction_id: Optional[int] = None) -> tuple[str | None, str | None]:
        """
        Main entry point for orchestrating a complex task using simulated agents.
        
        Args:
            task_description (str): The high-level task or query from the user.
            user_id (int): The Discord user ID initiating the task.
            channel_id (int): The Discord channel ID where the task originated.
            interaction_id (Optional[int]): The ID of the initial interaction record, if available.
                                            Used for linking sub-interactions and feedback.

        Returns:
            tuple[str | None, str | None]: A tuple containing the final response and an error message, if any.
        """
        self.logger.info(f"Orchestrating task for user {user_id} in channel {channel_id}: '{task_description}'")
        final_response = None
        error_message = None
        
        # 1. Retrieve relevant context from short-term and long-term memory
        short_context = self.short_term_memory.get_context(user_id, channel_id)
        long_context_data = self.long_term_memory.retrieve_relevant_context(user_id, channel_id, query=task_description)
        
        # Format long-term context for AI (e.g., as a string summary)
        long_context_str = "\n".join([f"{item['role']}: {item['content']}" for item in long_context_data])
        
        # Combine contexts for the initial planning phase
        full_context = f"Previous short-term conversation: {short_context}\nLong-term memory insights: {long_context_str}"
        
        # 2. Planning Phase: Use a "Planning Agent" to break down the task
        self.logger.debug("Planning phase initiated.")
        plan_steps = await self._generate_plan(task_description, full_context)
        
        if not plan_steps:
            error_message = "Failed to generate a plan for the task."
            self.logger.error(error_message)
            return None, error_message

        self.logger.debug(f"Generated plan: {plan_steps}")
        
        intermediate_results = []

        try:
            # 3. Execution Phase: Iterate through plan steps, using different "agents"
            for i, step in enumerate(plan_steps):
                self.logger.debug(f"Executing step {i+1}/{len(plan_steps)}: '{step}'")
                
                # Update short-term memory with the current step as context for the next AI call
                self.short_term_memory.add_message(user_id, channel_id, "system", f"Current task step: {step}")
                
                # Retrieve updated short-term context for the current step execution
                step_context = self.short_term_memory.get_context(user_id, channel_id)
                
                # Determine agent role based on step content (simplified for now)
                # In a more advanced system, this would involve a classification model or tool use
                agent_role = "general_executor"
                if "knowledge" in step.lower() or "fact" in step.lower() or "information" in step.lower() or "graph" in step.lower():
                    agent_role = "knowledge_agent"
                elif "code" in step.lower() or "program" in step.lower() or "script" in step.lower() or "generate" in step.lower():
                    agent_role = "code_agent"
                elif "evaluate" in step.lower() or "review" in step.lower() or "critique" in step.lower() or "reflect" in step.lower():
                    agent_role = "reflection_agent"

                step_output, step_error = await self._execute_step(step, step_context, agent_role, user_id, channel_id)
                
                if step_error:
                    self.logger.warning(f"Error executing step '{step}': {step_error}")
                    # Decide whether to continue or fail. For now, we'll append error and try to continue.
                    intermediate_results.append(f"Error in step '{step}': {step_error}")
                    error_message = f"Partial execution error: {step_error}"
                else:
                    self.logger.debug(f"Step output: {step_output[:min(len(step_output), 100)]}...") # Log first 100 chars
                    intermediate_results.append(step_output)
                    # Add agent's output to short-term memory for subsequent steps
                    self.short_term_memory.add_message(user_id, channel_id, "assistant", step_output)
                    # Save important intermediate results to long-term memory
                    self.long_term_memory.save_context(user_id, channel_id, step_output, f"orchestrator_step_output_{agent_role}")

            # 4. Synthesis Phase: Use a "Synthesis Agent" to combine results
            self.logger.debug("Synthesis phase initiated.")
            final_response, synthesis_error = await self._synthesize_results(task_description, intermediate_results)
            
            if synthesis_error:
                error_message = f"Failed to synthesize final response: {synthesis_error}"
                self.logger.error(error_message)
                final_response = "I encountered an issue while synthesizing my response. Please try again."

        except Exception as e:
            self.logger.exception(f"An unexpected error occurred during orchestration: {e}")
            error_message = f"An internal error occurred during task orchestration: {e}"
            final_response = "I'm sorry, an unexpected error occurred while processing your request."
        finally:
            # 5. Reflection and Learning Phase (Optional, can be asynchronous)
            if interaction_id:
                self.logger.debug(f"Triggering self-evaluation for interaction {interaction_id}.")
                # This can be a fire-and-forget task or awaited depending on criticality
                # For now, we'll await it for simplicity in a synchronous flow, but in a real bot,
                # this might be offloaded to a background task.
                evaluation_results = await self.feedback_loop.request_self_evaluation(interaction_id)
                if evaluation_results:
                    self.logger.info(f"Self-evaluation completed for interaction {interaction_id}: {evaluation_results.get('overall_score')}")
                    # The feedback loop itself will handle adapting based on these results.

            # Clear short-term memory for this specific conversation after task completion
            self.short_term_memory.clear_context(user_id, channel_id)
            self.logger.info(f"Task orchestration completed for user {user_id}. Final response length: {len(final_response) if final_response else 0}")
            
            return final_response, error_message

    async def _generate_plan(self, task_description: str, context: str) -> List[str]:
        """
        Uses the Gemini Integrator (acting as a 'Planning Agent') to break down
        a complex task into a list of actionable steps.
        """
        planning_prompt = (
            f"You are a highly intelligent and meticulous task planning agent. "
            f"Your goal is to break down a user's request into a sequence of clear, atomic, and executable steps. "
            f"Consider the provided context to inform your plan. "
            f"Output your plan as a JSON list of strings, where each string is a step. "
            f"Example: ['Step 1: Research X', 'Step 2: Summarize Y', 'Step 3: Generate Z based on Y'].\n\n"
            f"User Request: {task_description}\n"
            f"Context: {context}\n\n"
            f"Plan (JSON list of steps):"
        )
        
        response, error = await self.gemini_integrator.send_text_prompt(planning_prompt)
        
        if error:
            self.logger.error(f"Planning agent failed: {error}")
            return []
        
        try:
            # Attempt to parse JSON. Gemini might sometimes return extra text.
            # We'll try to extract the JSON part if it's embedded.
            if response.strip().startswith("[") and response.strip().endswith("]"):
                plan = json.loads(response)
            else:
                # Try to find JSON within the response
                json_start = response.find('[')
                json_end = response.rfind(']')
                if json_start != -1 and json_end != -1 and json_end > json_start:
                    json_str = response[json_start : json_end + 1]
                    plan = json.loads(json_str)
                else:
                    raise ValueError("Response is not a valid JSON list.")

            if not isinstance(plan, list) or not all(isinstance(item, str) for item in plan):
                raise ValueError("Plan is not a list of strings.")
            return plan
        except json.JSONDecodeError as e:
            self.logger.error(f"Failed to parse planning agent response as JSON: {e}. Raw response: {response}")
            return [response] # Fallback: treat the whole response as a single step
        except ValueError as e:
            self.logger.error(f"Invalid planning agent response format: {e}. Raw response: {response}")
            return [response] # Fallback: treat the whole response as a single step

    async def _execute_step(self, 
                           step: str, 
                           current_context: List[Dict[str, str]], 
                           agent_role: str,
                           user_id: int,
                           channel_id: int) -> tuple[str | None, str | None]:
        """
        Executes a single step of the plan using the appropriate simulated agent.
        
        Args:
            step (str): The specific step to execute.
            current_context (List[Dict[str, str]]): The current short-term conversation history.
            agent_role (str): The identified role for this step (e.g., "knowledge_agent", "code_agent").
            user_id (int): The Discord user ID.
            channel_id (int): The Discord channel ID.

        Returns:
            tuple[str | None, str | None]: The output of the step and an error message, if any.
        """
        self.logger.debug(f"Executing step with role '{agent_role}': '{step}'")
        
        # Prepare history for chat session
        history_for_gemini = [{"role": msg["role"], "parts": [msg["content"]]} for msg in current_context if msg["role"] in ["user", "assistant"]]

        # Agent-specific execution logic
        if agent_role == "knowledge_agent":
            # Simulate knowledge retrieval: use GraphQuery
            # The step itself might contain the query, or we ask Gemini to extract it
            query_extraction_prompt = (
                f"Given the following task step: '{step}', extract the core query "
                f"that needs to be performed against a knowledge graph. "
                f"Output only the query string, without any other text."
            )
            query_to_graph, query_error = await self.gemini_integrator.send_text_prompt(query_extraction_prompt)
            
            if query_error or not query_to_graph:
                self.logger.warning(f"Could not extract query for knowledge agent: {query_error or 'No query extracted'}")
                # Fallback: use the step itself as a general prompt
                return await self.gemini_integrator.send_text_prompt(step, history=history_for_gemini)
            
            self.logger.debug(f"Knowledge agent query: {query_to_graph}")
            nodes = self.graph_query.find_nodes(label=query_to_graph) # Simple direct lookup for now
            if nodes:
                node_details = self.graph_query.get_node_details(nodes[0].label)
                if node_details:
                    return f"Found knowledge: {node_details.get('description', nodes[0].label)}. Related info: {node_details.get('relationships', 'None')}", None
                else:
                    return f"Found node '{nodes[0].label}' but no detailed description.", None
            else:
                # If no direct node, try to use Gemini to answer based on general knowledge + context
                self.logger.info(f"No direct knowledge graph node found for '{query_to_graph}'. Using general AI.")
                return await self.gemini_integrator.send_text_prompt(f"Based on the following context, answer: {query_to_graph}", history=history_for_gemini)

        elif agent_role == "code_agent":
            # Simulate code generation/optimization
            code_prompt = (
                f"You are a highly skilled programming assistant. "
                f"Given the following task: '{step}', and previous context, generate or optimize Python code. "
                f"Provide only the code block, optionally with a brief explanation before it. "
                f"Ensure the code is functional and follows best practices.\n\n"
                f"Context: {current_context}\n\n"
                f"Code:"
            )
            return await self.gemini_integrator.send_text_prompt(code_prompt, history=history_for_gemini)

        elif agent_role == "reflection_agent":
            # Simulate reflection: use SelfEvaluator
            # This agent would typically evaluate a *previous* output.
            # For simplicity, we'll have it reflect on the current step's instruction.
            # In a real scenario, it would take the output of a previous step.
            reflection_prompt = (
                f"You are a self-reflection agent. Analyze the following instruction: '{step}'. "
                f"Consider how a good AI response would address it, and what potential challenges or ambiguities exist. "
                f"Output your reflection."
            )
            reflection_output, reflection_error = await self.gemini_integrator.send_text_prompt(reflection_prompt, history=history_for_gemini)
            
            # If there was a previous interaction_id, we could trigger a formal self-evaluation here
            # For now, we'll just return the reflection text.
            return reflection_output, reflection_error

        else: # Default: general_executor
            # Use Gemini for general text generation, leveraging chat session for coherence
            self.logger.debug(f"Using general executor for step: '{step}'")
            
            # The prompt for the general executor should guide it to address the step
            general_prompt = f"Given the overall task and the current context, please execute the following step: '{step}'"
            
            return await self.gemini_integrator.send_text_prompt(general_prompt, history=history_for_gemini)

    async def _synthesize_results(self, original_task: str, intermediate_results: List[str]) -> tuple[str | None, str | None]:
        """
        Uses the Gemini Integrator (acting as a 'Synthesis Agent') to combine
        all intermediate results into a single, coherent final response.
        """
        synthesis_prompt = (
            f"You are a highly skilled synthesis agent. "
            f"Your goal is to combine the following original user request and a series of intermediate results "
            f"into a single, comprehensive, and coherent final answer. "
            f"Ensure the response directly addresses the original request and incorporates all relevant information "
            f"from the intermediate results. If there were errors, acknowledge them gracefully.\n\n"
            f"Original User Request: {original_task}\n\n"
            f"Intermediate Results:\n" + "\n".join([f"- {res}" for res in intermediate_results]) + "\n\n"
            f"Final Answer:"
        )
        
        response, error = await self.gemini_integrator.send_text_prompt(synthesis_prompt)
        
        if error:
            self.logger.error(f"Synthesis agent failed: {error}")
            return None, error
        
        return response, None