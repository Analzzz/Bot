import logging
import google.generativeai as genai
from google.api_core.exceptions import GoogleAPIError, ResourceExhausted
from config.settings import (
    GOOGLE_GEMINI_API_KEY,
    GEMINI_MAX_TOKENS,
    GEMINI_TEMPERATURE,
    GEMINI_TOP_P,
    GEMINI_TOP_K,
    LOG_LEVEL
)

class GeminiIntegrator:
    """
    A wrapper class for the Google Gemini API, handling requests, responses,
    and error management. It centralizes the configuration and interaction
    with the Gemini model, implementing a singleton pattern.
    """
    _instance = None
    _initialized = False

    def __new__(cls, *args, **kwargs):
        """
        Implements the singleton pattern to ensure only one instance of
        GeminiIntegrator exists.
        """
        if cls._instance is None:
            cls._instance = super(GeminiIntegrator, cls).__new__(cls)
        return cls._instance

    def __init__(self):
        """
        Initializes the Gemini API configuration and model parameters.
        This constructor logic runs only once due to the singleton pattern.
        """
        if not self._initialized:
            self.logger = logging.getLogger(__name__)
            self.logger.setLevel(LOG_LEVEL)

            if not GOOGLE_GEMINI_API_KEY:
                self.logger.critical("GOOGLE_GEMINI_API_KEY is not set in environment variables.")
                raise ValueError("GOOGLE_GEMINI_API_KEY is required to initialize GeminiIntegrator.")

            genai.configure(api_key=GOOGLE_GEMINI_API_KEY)
            self._model = None # The generative model instance, lazily loaded

            self.generation_config = {
                "max_output_tokens": GEMINI_MAX_TOKENS,
                "temperature": GEMINI_TEMPERATURE,
                "top_p": GEMINI_TOP_P,
                "top_k": GEMINI_TOP_K,
            }

            # Define safety settings to block harmful content
            self.safety_settings = [
                {"category": "HARM_CATEGORY_HARASSMENT", "threshold": "BLOCK_MEDIUM_AND_ABOVE"},
                {"category": "HARM_CATEGORY_HATE_SPEECH", "threshold": "BLOCK_MEDIUM_AND_ABOVE"},
                {"category": "HARM_CATEGORY_SEXUALLY_EXPLICIT", "threshold": "BLOCK_MEDIUM_AND_ABOVE"},
                {"category": "HARM_CATEGORY_DANGEROUS_CONTENT", "threshold": "BLOCK_MEDIUM_AND_ABOVE"},
            ]
            self.logger.info("GeminiIntegrator initialized successfully.")
            self._initialized = True

    def _get_model(self):
        """
        Lazily loads and returns the configured Gemini generative model.
        The model is instantiated only once upon its first request.
        """
        if self._model is None:
            try:
                self._model = genai.GenerativeModel(
                    model_name="gemini-pro",
                    generation_config=self.generation_config,
                    safety_settings=self.safety_settings
                )
                self.logger.debug("Gemini generative model loaded.")
            except Exception as e:
                self.logger.error(f"Failed to load Gemini model: {e}")
                raise RuntimeError(f"Could not load Gemini model: {e}") from e
        return self._model

    async def send_text_prompt(self, prompt: str, history: list = None) -> tuple[str | None, str | None]:
        """
        Sends a text prompt to the Gemini model for single-turn generation.
        Handles various API errors and content blocking.

        Args:
            prompt (str): The text prompt to send to the model.
            history (list, optional): A list of previous messages in the format
                                      [{"role": "user", "parts": ["text"]}, {"role": "model", "parts": ["text"]}, ...].
                                      If provided, the prompt is appended to this history to form the full context.

        Returns:
            tuple[str | None, str | None]: A tuple containing the generated response text
                                           and an error message. If successful, error_message is None.
                                           If an error occurs, response_text is None.
        """
        model = self._get_model()
        if not model:
            return None, "Gemini model not initialized or failed to load."

        contents = []
        if history:
            # Ensure history is correctly formatted for the model
            for item in history:
                if "role" in item and "parts" in item and isinstance(item["parts"], list):
                    contents.append(item)
                else:
                    self.logger.warning(f"Invalid history item format: {item}. Skipping.")
        
        contents.append({"role": "user", "parts": [prompt]})

        try:
            response = await model.generate_content(contents=contents)
            
            # Check if any candidates were returned and if the first candidate has content
            if response.candidates and response.candidates[0].content.parts:
                return response.candidates[0].content.parts[0].text, None
            else:
                self.logger.warning(f"Gemini returned no candidates or empty content for prompt: {prompt}")
                return None, "Gemini returned no content. This might be due to safety settings or an empty response."

        except genai.types.BlockedPromptException as e:
            self.logger.warning(f"Prompt blocked by Gemini safety settings: {e}")
            return None, "Your prompt was blocked by AI safety settings. Please try rephrasing."
        except genai.types.StopCandidateException as e:
            self.logger.warning(f"Gemini generation stopped prematurely: {e}")
            return None, "AI response stopped prematurely. This can happen due to safety settings or length constraints."
        except ResourceExhausted as e:
            self.logger.error(f"Gemini API rate limit or quota exceeded: {e}")
            return None, "The AI service is currently busy or has exceeded its usage limits. Please try again later."
        except GoogleAPIError as e:
            self.logger.error(f"Google Gemini API error: {e}")
            return None, f"An error occurred with the AI service: {e}"
        except Exception as e:
            self.logger.exception(f"An unexpected error occurred during Gemini API call for prompt: {prompt}")
            return None, f"An unexpected error occurred: {e}"

    def start_chat_session(self, history: list = None):
        """
        Starts a new chat session with the Gemini model. This allows for multi-turn conversations.

        Args:
            history (list, optional): Initial chat history to prime the session.
                                      Format: [{"role": "user", "parts": ["text"]}, {"role": "model", "parts": ["text"]}, ...]

        Returns:
            genai.ChatSession: An active chat session object, or None if the model cannot be initialized.
        """
        model = self._get_model()
        if not model:
            self.logger.error("Cannot start chat session: Gemini model not initialized.")
            return None
        
        initial_history = []
        if history:
            for item in history:
                if "role" in item and "parts" in item and isinstance(item["parts"], list):
                    initial_history.append(item)
                else:
                    self.logger.warning(f"Invalid history item format: {item}. Skipping for chat session.")

        return model.start_chat(history=initial_history)

    async def send_chat_message(self, chat_session: genai.ChatSession, message: str) -> tuple[str | None, str | None]:
        """
        Sends a message within an existing Gemini chat session.

        Args:
            chat_session (genai.ChatSession): The active chat session object obtained from start_chat_session.
            message (str): The message to send to the chat.

        Returns:
            tuple[str | None, str | None]: A tuple containing the generated response text
                                           and an error message. If successful, error_message is None.
                                           If an error occurs, response_text is None.
        """
        if not chat_session:
            return None, "No active chat session provided."

        try:
            response = await chat_session.send_message(message)
            if response.candidates and response.candidates[0].content.parts:
                return response.candidates[0].content.parts[0].text, None
            else:
                self.logger.warning(f"Gemini returned no candidates or empty content for chat message: {message}")
                return None, "Gemini returned no content. This might be due to safety settings or an empty response."

        except genai.types.BlockedPromptException as e:
            self.logger.warning(f"Chat message blocked by Gemini safety settings: {e}")
            return None, "Your message was blocked by AI safety settings. Please try rephrasing."
        except genai.types.StopCandidateException as e:
            self.logger.warning(f"Gemini chat generation stopped prematurely: {e}")
            return None, "AI response stopped prematurely. This can happen due to safety settings or length constraints."
        except ResourceExhausted as e:
            self.logger.error(f"Gemini API rate limit or quota exceeded during chat: {e}")
            return None, "The AI service is currently busy or has exceeded its usage limits. Please try again later."
        except GoogleAPIError as e:
            self.logger.error(f"Google Gemini API error during chat: {e}")
            return None, f"An error occurred with the AI service during chat: {e}"
        except Exception as e:
            self.logger.exception(f"An unexpected error occurred during Gemini chat API call for message: {message}")
            return None, f"An unexpected error occurred during chat: {e}"