import logging
from typing import Dict, Any, Optional, List, Tuple

from config.settings import LOG_LEVEL
from src.ai_engine.gemini_integrator import GeminiIntegrator
from src.ai_engine.context_memory.short_term_memory import ShortTermMemory
from src.ai_engine.context_memory.long_term_memory import LongTermMemory
from src.ai_engine.knowledge_graph.graph_builder import GraphBuilder
from src.ai_engine.knowledge_graph.graph_query import GraphQuery
from src.ai_engine.multi_agent.agent_definitions import AgentDefinitions

class CodeGenerator:
    """
    Lógica para geração, otimização e depuração de código com base em requisitos
    e contexto fornecidos. Utiliza o modelo Google Gemini e integra-se com
    os módulos de memória e grafo de conhecimento do bot.
    Implementa o padrão singleton para garantir uma única instância.
    """
    _instance = None

    def __new__(cls, *args, **kwargs):
        """
        Implementa o padrão singleton para garantir que apenas uma instância de
        CodeGenerator exista.
        """
        if cls._instance is None:
            cls._instance = super(CodeGenerator, cls).__new__(cls)
            cls._instance._initialized = False # Flag to ensure __init__ runs only once
        return cls._instance

    def __init__(self):
        """
        Inicializa o CodeGenerator, configurando o logger e as instâncias dos
        componentes necessários do motor de IA. Esta lógica de construtor é
        executada apenas uma vez devido ao padrão singleton.
        """
        if self._initialized:
            return
        self.logger = logging.getLogger(__name__)
        self.logger.setLevel(LOG_LEVEL)

        self.gemini_integrator = GeminiIntegrator()
        self.short_term_memory = ShortTermMemory()
        self.long_term_memory = LongTermMemory()
        self.graph_builder = GraphBuilder() # Potentially for storing/retrieving code patterns
        self.graph_query = GraphQuery()     # Potentially for querying code patterns
        self.agent_definitions = AgentDefinitions()

        self._initialized = True
        self.logger.info("CodeGenerator initialized.")

    async def process_code_request(self,
                                    request_type: str, # e.g., "generate", "optimize", "debug"
                                    user_query: str,
                                    user_id: int,
                                    channel_id: int,
                                    additional_context: Optional[str] = None) -> Tuple[str | None, str | None]:
        """
        Processa uma solicitação de código (geração, otimização ou depuração)
        utilizando o modelo Gemini e o contexto do bot.

        Args:
            request_type (str): O tipo de solicitação de código (e.g., "generate", "optimize", "debug").
            user_query (str): A consulta original do usuário ou o código a ser processado.
            user_id (int): O ID do usuário que fez a solicitação.
            channel_id (int): O ID do canal onde a solicitação foi feita.
            additional_context (Optional[str]): Qualquer contexto adicional fornecido pelo usuário.

        Returns:
            Tuple[str | None, str | None]: Uma tupla contendo o código gerado/otimizado/depurado
                                           e uma mensagem de erro, se houver.
        """
        self.logger.info(f"Processing code request '{request_type}' for user {user_id} in channel {channel_id}.")

        code_agent_prompt = self.agent_definitions.get_agent_system_prompt("Code Agent")
        if not code_agent_prompt:
            error_msg = "Failed to retrieve Code Agent definition. Cannot process code request."
            self.logger.error(error_msg)
            return None, error_msg

        # Retrieve context from memory modules
        short_term_ctx = self.short_term_memory.get_context(user_id, channel_id)
        long_term_ctx = self.long_term_memory.retrieve_relevant_context(user_id, channel_id, query=user_query)

        # Prepare the full prompt for Gemini based on request type
        prompt_description = ""
        if request_type == "generate":
            prompt_description = "Generate code based on the following requirements:"
        elif request_type == "optimize":
            prompt_description = "Optimize the following code for performance, readability, or specific goals:"
        elif request_type == "debug":
            prompt_description = "Debug the following code. If an error message is provided, consider it:"
        else:
            prompt_description = "Process the following code-related request:"

        full_prompt_parts = [
            f"{prompt_description}\n```\n{user_query}\n```",
        ]

        if additional_context:
            full_prompt_parts.append(f"Additional context/details: {additional_context}")

        if long_term_ctx:
            # Format long-term context for inclusion in the prompt
            # Assuming 'content' is the relevant text and 'timestamp' for ordering/context.
            formatted_long_term_ctx = "\n".join([f"Past interaction ({item['timestamp']}): {item['content']}" for item in long_term_ctx])
            full_prompt_parts.append(f"\nRelevant past conversations:\n{formatted_long_term_ctx}")

        # Query knowledge graph for relevant code patterns/examples based on user_query
        # This is a placeholder for more advanced KG integration (e.g., semantic search).
        # For now, a simple label match is used.
        kg_relevant_nodes = self.graph_query.find_nodes(label=user_query, node_type="code_pattern")
        if kg_relevant_nodes:
            kg_info = "\n".join([f"Knowledge Graph Node: {node.label} (Type: {node.node_type}, Desc: {node.description})" for node in kg_relevant_nodes])
            full_prompt_parts.append(f"\nRelevant knowledge graph information:\n{kg_info}")

        # Combine all parts into the final user-facing prompt
        final_user_prompt = "\n\n".join(full_prompt_parts)

        # Construct the full prompt including the agent's system prompt.
        # This is prepended to the user's prompt as send_text_prompt does not take a system_instruction directly.
        full_gemini_prompt = f"{code_agent_prompt}\n\n{final_user_prompt}"

        response_content, error = await self.gemini_integrator.send_text_prompt(
            prompt=full_gemini_prompt,
            history=short_term_ctx # Pass short-term context as history for the current turn
        )

        if error:
            self.logger.error(f"Error during code processing: {error}")
            return None, f"An error occurred during code processing: {error}"

        if not response_content:
            return None, "The AI did not return any code or response."

        # Add the bot's response to short-term memory for potential follow-up
        self.short_term_memory.add_message(user_id, channel_id, "model", response_content)
        # Save the interaction to long-term memory for future context retrieval
        self.long_term_memory.save_context(user_id, channel_id, response_content, f"ai_code_{request_type}_response")

        self.logger.info(f"Code request '{request_type}' processed successfully for user {user_id}.")
        return response_content, None