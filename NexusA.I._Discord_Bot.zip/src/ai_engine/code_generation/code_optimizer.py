import logging
from typing import Dict, Any, Optional, List, Tuple
import re

from config.settings import LOG_LEVEL
from src.ai_engine.gemini_integrator import GeminiIntegrator
from src.ai_engine.context_memory.short_term_memory import ShortTermMemory
from src.ai_engine.context_memory.long_term_memory import LongTermMemory
from src.ai_engine.knowledge_graph.graph_query import GraphQuery
from src.ai_engine.multi_agent.agent_definitions import AgentDefinitions

class CodeOptimizer:
    """
    Lógica para otimização e refatoração de código gerado ou fornecido,
    com base em critérios de performance e boas práticas.
    Implementa o padrão singleton para garantir uma única instância.
    """
    _instance = None
    _initialized = False

    def __new__(cls, *args, **kwargs):
        """
        Implementa o padrão singleton para garantir que apenas uma instância de
        CodeOptimizer exista.
        """
        if cls._instance is None:
            cls._instance = super(CodeOptimizer, cls).__new__(cls)
        return cls._instance

    def __init__(self):
        """
        Inicializa o CodeOptimizer, configurando o logger e as instâncias dos
        componentes necessários do motor de IA. Esta lógica de construtor é
        executada apenas uma vez devido ao padrão singleton.
        """
        if not self._initialized:
            self.logger = logging.getLogger(__name__)
            self.logger.setLevel(LOG_LEVEL)
            self.gemini_integrator = GeminiIntegrator()
            self.short_term_memory = ShortTermMemory()
            self.long_term_memory = LongTermMemory()
            self.graph_query = GraphQuery()
            self.agent_definitions = AgentDefinitions()
            self.logger.info("CodeOptimizer initialized.")
            self._initialized = True

    async def optimize_code(self, 
                            code: str, 
                            optimization_goals: List[str], 
                            user_id: int, 
                            channel_id: int, 
                            context: Optional[str] = None) -> Tuple[str | None, str | None]:
        """
        Solicita ao modelo de IA a otimização ou refatoração de um trecho de código.

        Args:
            code (str): O trecho de código a ser otimizado.
            optimization_goals (List[str]): Uma lista de objetivos de otimização
                                            (e.g., ["performance", "readability", "security", "refactor"]).
            user_id (int): O ID do usuário para recuperar contexto de memória.
            channel_id (int): O ID do canal para recuperar contexto de memória.
            context (Optional[str]): Contexto adicional específico para a otimização.

        Returns:
            Tuple[str | None, str | None]: Uma tupla contendo o código otimizado e uma explicação,
                                           ou (None, mensagem_de_erro) em caso de falha.
        """
        self.logger.info(f"Iniciando otimização de código para user_id={user_id}, channel_id={channel_id}")
        
        # 1. Obter o prompt do agente de código (que inclui otimização)
        code_agent_prompt = self.agent_definitions.get_agent_system_prompt("Code Agent")
        if not code_agent_prompt:
            error_msg = "Definição do agente 'Code Agent' não encontrada. Certifique-se de que o agente está configurado corretamente."
            self.logger.error(error_msg)
            return None, error_msg

        # 2. Recuperar contexto relevante da memória de curto prazo
        short_term_ctx_history = self.short_term_memory.get_context(user_id, channel_id)
        short_term_ctx_str = ""
        if short_term_ctx_history:
            # Formata o histórico para ser incluído no prompt
            formatted_history = []
            for msg in short_term_ctx_history:
                role = msg['role'].capitalize()
                content = msg['parts'][0]['text']
                formatted_history.append(f"{role}: {content}")
            short_term_ctx_str = "\n".join(formatted_history)
            short_term_ctx_str = f"Histórico da conversa recente:\n{short_term_ctx_str}\n"

        # 3. Construir o prompt detalhado para o Gemini
        goals_str = ", ".join(optimization_goals)
        
        prompt_parts = [
            code_agent_prompt, # Instrução de sistema para o Agente de Código
            f"Você é um especialista em otimização de código. Sua tarefa é otimizar o código fornecido com os seguintes objetivos: {goals_str}.",
            "Forneça o código otimizado dentro de um bloco de código markdown (especifique a linguagem, e.g., ```python) e, em seguida, uma explicação detalhada das mudanças e por que elas foram feitas, destacando as melhorias em relação aos objetivos.",
            "Se o código for inviável ou não puder ser otimizado conforme solicitado, explique o motivo claramente e sugira alternativas.",
            "\n--- Código Original ---\n",
            code,
            "\n--- Contexto Adicional ---\n",
            short_term_ctx_str, # Inclui o contexto formatado
            f"Contexto específico fornecido: {context if context else 'Nenhum.'}",
            "\n--- Sua Resposta (Código Otimizado e Explicação) ---\n"
        ]
        
        full_prompt = "\n".join(prompt_parts)
        
        self.logger.debug(f"Enviando prompt de otimização para Gemini:\n{full_prompt[:1000]}...") # Log dos primeiros 1000 caracteres

        # 4. Enviar o prompt para o Gemini
        optimized_response, error = await self.gemini_integrator.send_text_prompt(full_prompt)

        if error:
            self.logger.error(f"Erro ao otimizar código com Gemini: {error}")
            return None, f"Ocorreu um erro ao tentar otimizar o código: {error}"

        if not optimized_response:
            self.logger.warning("Gemini retornou uma resposta vazia para otimização de código.")
            return None, "Não foi possível obter uma resposta de otimização do modelo de IA."

        # 5. Parsear a resposta do Gemini para extrair o código e a explicação
        optimized_code = None
        explanation = optimized_response

        # Expressão regular para encontrar blocos de código markdown (```[linguagem]\ncódigo\n```)
        code_block_pattern = re.compile(r"```(?P<lang>\w+)?\n(?P<code>.*?)\n```", re.DOTALL)
        
        match = code_block_pattern.search(optimized_response)
        if match:
            optimized_code = match.group("code").strip()
            # Remove o bloco de código encontrado da string de resposta para deixar apenas a explicação
            explanation = code_block_pattern.sub("", optimized_response, 1).strip()
        else:
            self.logger.warning("Nenhum bloco de código markdown encontrado na resposta do Gemini. Retornando a resposta completa como explicação.")
            # Se nenhum bloco de código for encontrado, a resposta inteira é considerada a explicação.
            explanation = optimized_response
            
        return optimized_code, explanation