import logging
import json
from src.core.database_manager import DatabaseManager
from src.data.models import KnowledgeNode, KnowledgeEdge
from config.settings import LOG_LEVEL
from sqlalchemy.exc import SQLAlchemyError
from sqlalchemy.orm import joinedload

class GraphBuilder:
    """
    Manages the construction and maintenance of the bot's knowledge graph.
    This class provides methods to add, retrieve, and manage nodes and edges
    within the database-backed knowledge graph.
    Implements a singleton pattern to ensure a single point of control for graph operations.
    """
    _instance = None
    _initialized = False

    def __new__(cls, *args, **kwargs):
        """
        Implements the singleton pattern to ensure only one instance of
        GraphBuilder exists.
        """
        if cls._instance is None:
            cls._instance = super(GraphBuilder, cls).__new__(cls)
        return cls._instance

    def __init__(self):
        """
        Initializes the GraphBuilder, setting up logging and database manager.
        This constructor logic runs only once due to the singleton pattern.
        """
        if not self._initialized:
            self.logger = logging.getLogger(__name__)
            self.logger.setLevel(LOG_LEVEL)
            self.db_manager = DatabaseManager()
            self._initialized = True
            self.logger.info("GraphBuilder initialized.")

    def add_node(self, label: str, node_type: str = "concept", description: str = None) -> KnowledgeNode:
        """
        Adds a new node to the knowledge graph or returns an existing one if a node
        with the given label already exists.

        Args:
            label (str): The unique label for the node (e.g., "Python", "Google Gemini API").
            node_type (str): The type of the node (e.g., "concept", "person", "tool", "event").
            description (str, optional): A brief description of the node. Defaults to None.

        Returns:
            KnowledgeNode: The newly created or existing KnowledgeNode object.
        """
        with self.db_manager.get_session() as session:
            try:
                existing_node = session.query(KnowledgeNode).filter_by(label=label).first()
                if existing_node:
                    self.logger.debug(f"Node with label '{label}' already exists. Returning existing node.")
                    return existing_node

                new_node = KnowledgeNode(label=label, node_type=node_type, description=description)
                session.add(new_node)
                session.commit()
                session.refresh(new_node)
                self.logger.info(f"Added new node: {new_node}")
                return new_node
            except SQLAlchemyError as e:
                session.rollback()
                self.logger.error(f"Error adding node '{label}': {e}")
                raise

    def add_edge(self, source_node: KnowledgeNode, target_node: KnowledgeNode, relationship_type: str, properties: dict = None) -> KnowledgeEdge:
        """
        Adds a new edge (relationship) between two nodes in the knowledge graph.
        Prevents duplicate edges with the exact same source, target, and relationship type.

        Args:
            source_node (KnowledgeNode): The source node of the relationship.
            target_node (KnowledgeNode): The target node of the relationship.
            relationship_type (str): The type of relationship (e.g., "IS_A", "HAS_PROPERTY", "USES").
            properties (dict, optional): A dictionary of properties for the edge. Defaults to None.

        Returns:
            KnowledgeEdge: The newly created or existing KnowledgeEdge object.
        """
        if not all([source_node, target_node, relationship_type]):
            self.logger.error("Cannot add edge: source_node, target_node, and relationship_type must be provided.")
            raise ValueError("Source node, target node, and relationship type are required.")
        
        if not isinstance(source_node, KnowledgeNode) or not isinstance(target_node, KnowledgeNode):
            self.logger.error("Source and target must be KnowledgeNode objects.")
            raise TypeError("Source and target must be KnowledgeNode objects.")

        properties_json = json.dumps(properties) if properties else None

        with self.db_manager.get_session() as session:
            try:
                # Check for existing edge to prevent duplicates
                existing_edge = session.query(KnowledgeEdge).filter_by(
                    source_node_id=source_node.id,
                    target_node_id=target_node.id,
                    relationship_type=relationship_type
                ).first()

                if existing_edge:
                    self.logger.debug(f"Edge '{relationship_type}' from '{source_node.label}' to '{target_node.label}' already exists. Returning existing edge.")
                    return existing_edge

                new_edge = KnowledgeEdge(
                    source_node_id=source_node.id,
                    target_node_id=target_node.id,
                    relationship_type=relationship_type,
                    properties=properties_json
                )
                session.add(new_edge)
                session.commit()
                session.refresh(new_edge)
                self.logger.info(f"Added new edge: {new_edge}")
                return new_edge
            except SQLAlchemyError as e:
                session.rollback()
                self.logger.error(f"Error adding edge from '{source_node.label}' to '{target_node.label}' with type '{relationship_type}': {e}")
                raise

    def get_node_by_label(self, label: str) -> KnowledgeNode | None:
        """
        Retrieves a knowledge node by its unique label.

        Args:
            label (str): The label of the node to retrieve.

        Returns:
            KnowledgeNode | None: The KnowledgeNode object if found, otherwise None.
        """
        with self.db_manager.get_session() as session:
            try:
                node = session.query(KnowledgeNode).filter_by(label=label).first()
                if node:
                    self.logger.debug(f"Retrieved node by label '{label}': {node}")
                else:
                    self.logger.debug(f"Node with label '{label}' not found.")
                return node
            except SQLAlchemyError as e:
                self.logger.error(f"Error retrieving node by label '{label}': {e}")
                return None

    def get_edges_from_node(self, node: KnowledgeNode) -> list[KnowledgeEdge]:
        """
        Retrieves all outgoing edges from a given source node.

        Args:
            node (KnowledgeNode): The source node.

        Returns:
            list[KnowledgeEdge]: A list of KnowledgeEdge objects originating from the node.
        """
        if not node or not node.id:
            self.logger.warning("Invalid node provided to get_edges_from_node.")
            return []

        with self.db_manager.get_session() as session:
            try:
                # Eagerly load source_node and target_node relationships for convenience
                edges = session.query(KnowledgeEdge)\
                               .options(joinedload(KnowledgeEdge.source_node), joinedload(KnowledgeEdge.target_node))\
                               .filter_by(source_node_id=node.id).all()
                self.logger.debug(f"Retrieved {len(edges)} outgoing edges from node '{node.label}'.")
                return edges
            except SQLAlchemyError as e:
                self.logger.error(f"Error retrieving outgoing edges from node '{node.label}': {e}")
                return []

    def get_edges_to_node(self, node: KnowledgeNode) -> list[KnowledgeEdge]:
        """
        Retrieves all incoming edges to a given target node.

        Args:
            node (KnowledgeNode): The target node.

        Returns:
            list[KnowledgeEdge]: A list of KnowledgeEdge objects pointing to the node.
        """
        if not node or not node.id:
            self.logger.warning("Invalid node provided to get_edges_to_node.")
            return []

        with self.db_manager.get_session() as session:
            try:
                # Eagerly load source_node and target_node relationships for convenience
                edges = session.query(KnowledgeEdge)\
                               .options(joinedload(KnowledgeEdge.source_node), joinedload(KnowledgeEdge.target_node))\
                               .filter_by(target_node_id=node.id).all()
                self.logger.debug(f"Retrieved {len(edges)} incoming edges to node '{node.label}'.")
                return edges
            except SQLAlchemyError as e:
                self.logger.error(f"Error retrieving incoming edges to node '{node.label}': {e}")
                return []

    def get_related_nodes(self, node: KnowledgeNode, relationship_type: str = None) -> list[KnowledgeNode]:
        """
        Retrieves all nodes directly related to a given node (both incoming and outgoing relationships),
        optionally filtered by relationship type.

        Args:
            node (KnowledgeNode): The central node.
            relationship_type (str, optional): If provided, only relationships of this type are considered.

        Returns:
            list[KnowledgeNode]: A list of unique KnowledgeNode objects related to the central node.
        """
        if not node or not node.id:
            self.logger.warning("Invalid node provided to get_related_nodes.")
            return []

        related_nodes = set()
        with self.db_manager.get_session() as session:
            try:
                # Get outgoing relationships
                query_outgoing = session.query(KnowledgeEdge)\
                                        .options(joinedload(KnowledgeEdge.target_node))\
                                        .filter_by(source_node_id=node.id)
                if relationship_type:
                    query_outgoing = query_outgoing.filter_by(relationship_type=relationship_type)
                outgoing_edges = query_outgoing.all()

                for edge in outgoing_edges:
                    if edge.target_node: # target_node is eagerly loaded
                        related_nodes.add(edge.target_node)

                # Get incoming relationships
                query_incoming = session.query(KnowledgeEdge)\
                                        .options(joinedload(KnowledgeEdge.source_node))\
                                        .filter_by(target_node_id=node.id)
                if relationship_type:
                    query_incoming = query_incoming.filter_by(relationship_type=relationship_type)
                incoming_edges = query_incoming.all()

                for edge in incoming_edges:
                    if edge.source_node: # source_node is eagerly loaded
                        related_nodes.add(edge.source_node)

                self.logger.debug(f"Retrieved {len(related_nodes)} related nodes for '{node.label}' (type: {relationship_type or 'any'}).")
                return list(related_nodes)
            except SQLAlchemyError as e:
                self.logger.error(f"Error retrieving related nodes for '{node.label}': {e}")
                return []