import logging
from collections import deque
from typing import List, Dict, Optional, Tuple, Union

from sqlalchemy.exc import SQLAlchemyError
from sqlalchemy.orm import joinedload

from config.settings import LOG_LEVEL
from src.core.database_manager import DatabaseManager
from src.data.models import KnowledgeNode, KnowledgeEdge

class GraphQuery:
    """
    Manages querying and retrieving information from the bot's knowledge graph.
    This class provides methods to search for nodes and edges, traverse relationships,
    and extract structured information from the database-backed knowledge graph.
    Implements a singleton pattern to ensure a single point of control for graph queries.
    """
    _instance = None
    _initialized = False

    def __new__(cls, *args, **kwargs):
        """
        Implements the singleton pattern to ensure only one instance of
        GraphQuery exists.
        """
        if cls._instance is None:
            cls._instance = super(GraphQuery, cls).__new__(cls)
        return cls._instance

    def __init__(self):
        """
        Initializes the GraphQuery, setting up logging and database manager.
        This constructor logic runs only once due to the singleton pattern.
        """
        if not self._initialized:
            self.logger = logging.getLogger(__name__)
            self.logger.setLevel(LOG_LEVEL)
            self.db_manager = DatabaseManager()
            self._initialized = True
            self.logger.info("GraphQuery initialized.")

    def find_nodes(self, label: Optional[str] = None, node_type: Optional[str] = None) -> List[KnowledgeNode]:
        """
        Finds knowledge nodes based on optional label (partial match) and node type.

        Args:
            label (str, optional): A substring to match against node labels. Case-insensitive.
            node_type (str, optional): The type of the node (e.g., "concept", "person", "event").

        Returns:
            List[KnowledgeNode]: A list of matching KnowledgeNode objects.
        """
        self.logger.debug(f"Finding nodes with label='{label}' and type='{node_type}'")
        with self.db_manager.get_session() as session:
            try:
                query = session.query(KnowledgeNode)
                if label:
                    query = query.filter(KnowledgeNode.label.ilike(f"%{label}%"))
                if node_type:
                    query = query.filter_by(node_type=node_type)
                
                nodes = query.all()
                self.logger.debug(f"Found {len(nodes)} nodes.")
                return nodes
            except SQLAlchemyError as e:
                self.logger.error(f"Database error finding nodes: {e}")
                return []

    def find_edges(self, 
                   source_label: Optional[str] = None, 
                   target_label: Optional[str] = None, 
                   relationship_type: Optional[str] = None) -> List[KnowledgeEdge]:
        """
        Finds knowledge edges based on optional source node label, target node label,
        and/or relationship type.

        Args:
            source_label (str, optional): The label of the source node.
            target_label (str, optional): The label of the target node.
            relationship_type (str, optional): The type of the relationship (e.g., "IS_A", "HAS_PROPERTY").

        Returns:
            List[KnowledgeEdge]: A list of matching KnowledgeEdge objects.
        """
        self.logger.debug(f"Finding edges: source='{source_label}', target='{target_label}', type='{relationship_type}'")
        with self.db_manager.get_session() as session:
            try:
                query = session.query(KnowledgeEdge).options(
                    joinedload(KnowledgeEdge.source_node),
                    joinedload(KnowledgeEdge.target_node)
                )

                if source_label:
                    query = query.join(KnowledgeNode, KnowledgeEdge.source_node_id == KnowledgeNode.id)\
                                 .filter(KnowledgeNode.label.ilike(f"%{source_label}%"))
                if target_label:
                    # If source_label was also provided, we need to join KnowledgeNode again with an alias
                    if source_label:
                        TargetNode = KnowledgeNode.alias()
                        query = query.join(TargetNode, KnowledgeEdge.target_node_id == TargetNode.id)\
                                     .filter(TargetNode.label.ilike(f"%{target_label}%"))
                    else:
                        query = query.join(KnowledgeNode, KnowledgeEdge.target_node_id == KnowledgeNode.id)\
                                     .filter(KnowledgeNode.label.ilike(f"%{target_label}%"))
                if relationship_type:
                    query = query.filter(KnowledgeEdge.relationship_type.ilike(f"%{relationship_type}%"))
                
                edges = query.all()
                self.logger.debug(f"Found {len(edges)} edges.")
                return edges
            except SQLAlchemyError as e:
                self.logger.error(f"Database error finding edges: {e}")
                return []

    def get_connected_nodes(self, 
                            node_label: str, 
                            relationship_type: Optional[str] = None, 
                            direction: str = "both") -> List[Tuple[KnowledgeNode, KnowledgeEdge, KnowledgeNode]]:
        """
        Retrieves nodes connected to a specified node, optionally filtered by relationship type and direction.

        Args:
            node_label (str): The label of the central node.
            relationship_type (str, optional): The type of relationship to filter by.
            direction (str): "outgoing", "incoming", or "both". Defaults to "both".

        Returns:
            List[Tuple[KnowledgeNode, KnowledgeEdge, KnowledgeNode]]: A list of tuples,
            where each tuple contains (central_node, edge, connected_node).
        """
        self.logger.debug(f"Getting connected nodes for '{node_label}' with type='{relationship_type}', direction='{direction}'")
        results = []
        with self.db_manager.get_session() as session:
            try:
                central_node = session.query(KnowledgeNode).filter_by(label=node_label).first()
                if not central_node:
                    self.logger.warning(f"Node with label '{node_label}' not found.")
                    return []

                # Query for outgoing edges
                if direction in ["outgoing", "both"]:
                    outgoing_query = session.query(KnowledgeEdge).options(joinedload(KnowledgeEdge.target_node))\
                                            .filter(KnowledgeEdge.source_node_id == central_node.id)
                    if relationship_type:
                        outgoing_query = outgoing_query.filter_by(relationship_type=relationship_type)
                    
                    for edge in outgoing_query.all():
                        results.append((central_node, edge, edge.target_node))

                # Query for incoming edges
                if direction in ["incoming", "both"]:
                    incoming_query = session.query(KnowledgeEdge).options(joinedload(KnowledgeEdge.source_node))\
                                            .filter(KnowledgeEdge.target_node_id == central_node.id)
                    if relationship_type:
                        incoming_query = incoming_query.filter_by(relationship_type=relationship_type)
                    
                    for edge in incoming_query.all():
                        results.append((central_node, edge, edge.source_node))
                
                self.logger.debug(f"Found {len(results)} connections for '{node_label}'.")
                return results
            except SQLAlchemyError as e:
                self.logger.error(f"Database error getting connected nodes for '{node_label}': {e}")
                return []

    def get_node_details(self, label: str) -> Optional[Dict]:
        """
        Retrieves detailed information about a node, including its properties
        and directly connected relationships (edges and connected nodes).

        Args:
            label (str): The label of the node to retrieve details for.

        Returns:
            Optional[Dict]: A dictionary containing node details and its connections,
                            or None if the node is not found.
        """
        self.logger.debug(f"Getting details for node '{label}'")
        with self.db_manager.get_session() as session:
            try:
                node = session.query(KnowledgeNode).filter_by(label=label).first()
                if not node:
                    self.logger.warning(f"Node with label '{label}' not found for details query.")
                    return None

                details = {
                    "id": node.id,
                    "label": node.label,
                    "node_type": node.node_type,
                    "description": node.description,
                    "properties": node.properties,
                    "created_at": node.created_at.isoformat(),
                    "updated_at": node.updated_at.isoformat(),
                    "connections": []
                }

                # Get all outgoing and incoming edges for this node
                edges = session.query(KnowledgeEdge).options(
                    joinedload(KnowledgeEdge.source_node),
                    joinedload(KnowledgeEdge.target_node)
                ).filter(
                    (KnowledgeEdge.source_node_id == node.id) | 
                    (KnowledgeEdge.target_node_id == node.id)
                ).all()

                for edge in edges:
                    connected_node = None
                    direction = None
                    if edge.source_node_id == node.id:
                        connected_node = edge.target_node
                        direction = "outgoing"
                    elif edge.target_node_id == node.id:
                        connected_node = edge.source_node
                        direction = "incoming"
                    
                    if connected_node:
                        details["connections"].append({
                            "edge_id": edge.id,
                            "relationship_type": edge.relationship_type,
                            "properties": edge.properties,
                            "direction": direction,
                            "connected_node": {
                                "id": connected_node.id,
                                "label": connected_node.label,
                                "node_type": connected_node.node_type,
                                "description": connected_node.description
                            }
                        })
                
                self.logger.debug(f"Retrieved details for node '{label}'. Found {len(details['connections'])} connections.")
                return details
            except SQLAlchemyError as e:
                self.logger.error(f"Database error getting node details for '{label}': {e}")
                return None

    def get_path(self, start_label: str, end_label: str, max_depth: int = 5) -> Optional[List[Union[KnowledgeNode, KnowledgeEdge]]]:
        """
        Finds the shortest path (in terms of number of hops) between two nodes
        in the knowledge graph using a Breadth-First Search (BFS) algorithm.

        Args:
            start_label (str): The label of the starting node.
            end_label (str): The label of the target node.
            max_depth (int): The maximum number of hops to search for a path.

        Returns:
            Optional[List[Union[KnowledgeNode, KnowledgeEdge]]]: A list representing the path
            (alternating nodes and edges), or None if no path is found within max_depth.
        """
        self.logger.debug(f"Searching for path from '{start_label}' to '{end_label}' with max_depth={max_depth}")
        with self.db_manager.get_session() as session:
            try:
                start_node = session.query(KnowledgeNode).filter_by(label=start_label).first()
                end_node = session.query(KnowledgeNode).filter_by(label=end_label).first()

                if not start_node:
                    self.logger.warning(f"Start node '{start_label}' not found.")
                    return None
                if not end_node:
                    self.logger.warning(f"End node '{end_label}' not found.")
                    return None
                if start_node.id == end_node.id:
                    return [start_node]

                # BFS implementation
                queue = deque([(start_node, [start_node], 0)]) # (current_node, path_list, current_depth)
                visited_nodes = {start_node.id}

                while queue:
                    current_node, path, depth = queue.popleft()

                    if depth >= max_depth:
                        continue

                    # Find all outgoing and incoming edges for the current node
                    edges = session.query(KnowledgeEdge).options(
                        joinedload(KnowledgeEdge.source_node),
                        joinedload(KnowledgeEdge.target_node)
                    ).filter(
                        (KnowledgeEdge.source_node_id == current_node.id) | 
                        (KnowledgeEdge.target_node_id == current_node.id)
                    ).all()

                    for edge in edges:
                        neighbor_node = None
                        if edge.source_node_id == current_node.id:
                            neighbor_node = edge.target_node
                        elif edge.target_node_id == current_node.id:
                            neighbor_node = edge.source_node
                        
                        if neighbor_node and neighbor_node.id not in visited_nodes:
                            new_path = path + [edge, neighbor_node]
                            if neighbor_node.id == end_node.id:
                                self.logger.info(f"Path found from '{start_label}' to '{end_label}' at depth {depth + 1}.")
                                return new_path
                            
                            visited_nodes.add(neighbor_node.id)
                            queue.append((neighbor_node, new_path, depth + 1))
                
                self.logger.info(f"No path found from '{start_label}' to '{end_label}' within max_depth {max_depth}.")
                return None # No path found
            except SQLAlchemyError as e:
                self.logger.error(f"Database error during pathfinding from '{start_label}' to '{end_label}': {e}")
                return None