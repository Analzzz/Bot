import logging
from collections import deque
from config.settings import LOG_LEVEL

class ShortTermMemory:
    """
    Manages the short-term conversation context (current conversation turn)
    for the bot. This memory is ephemeral and focused on maintaining
    coherence within a single, ongoing interaction or a very recent sequence
    of messages.

    It uses an in-memory deque to store recent messages per user/channel,
    formatted for direct use with the Google Gemini API's chat sessions.
    Implements a singleton pattern to ensure a single, centralized memory store.
    """

    _instance = None
    _initialized = False

    def __new__(cls, *args, **kwargs):
        """
        Implements the singleton pattern to ensure only one instance of
        ShortTermMemory exists.
        """
        if cls._instance is None:
            cls._instance = super(ShortTermMemory, cls).__new__(cls)
        return cls._instance

    def __init__(self):
        """
        Initializes the short-term memory store.
        This constructor logic runs only once due to the singleton pattern.
        """
        if not self._initialized:
            self.logger = logging.getLogger(__name__)
            self.logger.setLevel(LOG_LEVEL)

            # Stores short-term context: {(user_id, channel_id): deque[{"role": str, "parts": [{"text": str}]}]}
            self._conversations: dict[tuple[int, int], deque] = {}

            # Maximum number of messages (user + model) to keep in short-term memory per conversation.
            # This is a heuristic to manage context length for AI models.
            # A value of 10 means 5 user messages and 5 bot responses.
            self._max_messages_per_context = 10 

            self.logger.info("ShortTermMemory initialized.")
            ShortTermMemory._initialized = True

    def add_message(self, user_id: int, channel_id: int, role: str, content: str):
        """
        Adds a message to the short-term memory for a specific conversation.
        Messages are stored in a format compatible with Gemini's chat history.

        Args:
            user_id (int): The Discord ID of the user involved in the conversation.
            channel_id (int): The Discord ID of the channel where the conversation is happening.
            role (str): The role of the message sender ("user" or "model").
            content (str): The text content of the message.
        """
        key = (user_id, channel_id)
        if key not in self._conversations:
            self._conversations[key] = deque(maxlen=self._max_messages_per_context)

        message = {"role": role, "parts": [{"text": content}]}
        self._conversations[key].append(message)
        self.logger.debug(f"Added message to short-term memory for {key}: {content[:50]}...")

    def get_context(self, user_id: int, channel_id: int) -> list[dict]:
        """
        Retrieves the current short-term conversation context for a given
        user and channel, formatted as a list of message dictionaries
        suitable for the Gemini API's `history` parameter.

        Args:
            user_id (int): The Discord ID of the user.
            channel_id (int): The Discord ID of the channel.

        Returns:
            list[dict]: A list of message dictionaries representing the short-term context.
                        Returns an empty list if no context exists for the given key.
        """
        key = (user_id, channel_id)
        context = list(self._conversations.get(key, deque()))
        self.logger.debug(f"Retrieved short-term context for {key} with {len(context)} messages.")
        return context

    def clear_context(self, user_id: int, channel_id: int):
        """
        Clears the short-term memory for a specific user and channel.
        This is useful for starting a fresh conversation or when the context
        is no longer relevant.

        Args:
            user_id (int): The Discord ID of the user.
            channel_id (int): The Discord ID of the channel.
        """
        key = (user_id, channel_id)
        if key in self._conversations:
            del self._conversations[key]
            self.logger.info(f"Cleared short-term memory for {key}.")
        else:
            self.logger.debug(f"No short-term memory found to clear for {key}.")