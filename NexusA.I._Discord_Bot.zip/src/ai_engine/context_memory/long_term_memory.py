import logging
from datetime import datetime

from src.core.database_manager import DatabaseManager
from src.data.models import ConversationContext # Assumed to have 'content', 'timestamp', and 'message_type' columns

from config.settings import LOG_LEVEL

class LongTermMemory:
    """
    Manages the long-term conversation context for the bot.
    Utilizes the database to persist and retrieve relevant past interactions,
    enabling the bot to maintain context across extended conversations.
    """

    def __init__(self):
        self.logger = logging.getLogger(__name__)
        self.logger.setLevel(LOG_LEVEL)
        self.db_manager = DatabaseManager()
        self.logger.info("LongTermMemory initialized.")

    def save_context(self, user_id: int, channel_id: int, content: str, message_type: str):
        """
        Saves a piece of conversation content into the long-term memory.

        Args:
            user_id (int): The Discord ID of the user involved.
            channel_id (int): The Discord ID of the channel where the conversation occurred.
            content (str): The text content of the message.
            message_type (str): The type of message ('user' or 'model'). This maps to Gemini's 'role'.
        """
        if not content or not content.strip():
            self.logger.debug("Attempted to save empty or whitespace-only context content. Skipping.")
            return

        with self.db_manager.get_session() as session:
            try:
                new_context = ConversationContext(
                    user_id=user_id,
                    channel_id=channel_id,
                    content=content,
                    timestamp=datetime.now(),
                    is_active=True, # Mark as active by default when saving
                    message_type=message_type # This column is assumed to exist in ConversationContext for Gemini compatibility
                )
                session.add(new_context)
                session.commit()
                self.logger.debug(f"Saved context for user {user_id} in channel {channel_id} (type: {message_type}): '{content[:70]}...'")
            except Exception as e:
                session.rollback()
                self.logger.error(f"Failed to save context for user {user_id} in channel {channel_id}: {e}")

    def retrieve_relevant_context(self, user_id: int, channel_id: int, query: str = None, limit: int = 10) -> list[dict]:
        """
        Retrieves relevant past conversation context for a given user and channel.
        Currently, relevance is determined by recency. Future implementations may
        incorporate semantic search using embeddings.

        Args:
            user_id (int): The Discord ID of the user.
            channel_id (int): The Discord ID of the channel.
            query (str, optional): The current query. Not used for relevance in this
                                   basic implementation but kept for future expansion.
            limit (int): The maximum number of past messages to retrieve.

        Returns:
            list[dict]: A list of dictionaries, each representing a message in a format
                        suitable for Gemini's chat history (e.g., {'role': 'user', 'parts': ['content']}).
        """
        relevant_history = []
        with self.db_manager.get_session() as session:
            try:
                # Fetch recent active conversations for the specific user and channel
                # Order by timestamp descending to get the most recent first
                # Then reverse the list to have oldest first for chat history
                context_entries = session.query(ConversationContext) \
                    .filter_by(user_id=user_id, channel_id=channel_id, is_active=True) \
                    .order_by(ConversationContext.timestamp.desc()) \
                    .limit(limit) \
                    .all()

                # Reverse to get chronological order for chat history
                context_entries.reverse()

                for entry in context_entries:
                    # Ensure message_type is valid for Gemini ('user' or 'model')
                    # Default to 'user' if message_type is somehow invalid or missing
                    role = entry.message_type if hasattr(entry, 'message_type') and entry.message_type in ['user', 'model'] else 'user'
                    relevant_history.append({
                        "role": role,
                        "parts": [entry.content]
                    })
                self.logger.debug(f"Retrieved {len(relevant_history)} context entries for user {user_id} in channel {channel_id}.")
            except Exception as e:
                self.logger.error(f"Failed to retrieve context for user {user_id} in channel {channel_id}: {e}")
        return relevant_history

    def clear_context(self, user_id: int, channel_id: int):
        """
        Marks all conversation context for a specific user and channel as inactive.
        This effectively "clears" the long-term memory for that specific conversation,
        without deleting the data. This is useful for starting a fresh conversation
        or managing memory limits.

        Args:
            user_id (int): The Discord ID of the user.
            channel_id (int): The Discord ID of the channel.
        """
        with self.db_manager.get_session() as session:
            try:
                # Find all active contexts for the user/channel and mark them inactive
                contexts_to_clear = session.query(ConversationContext) \
                    .filter_by(user_id=user_id, channel_id=channel_id, is_active=True) \
                    .all()

                if contexts_to_clear:
                    for context in contexts_to_clear:
                        context.is_active = False
                    session.commit()
                    self.logger.info(f"Cleared {len(contexts_to_clear)} active context entries for user {user_id} in channel {channel_id}.")
                else:
                    self.logger.debug(f"No active context entries found to clear for user {user_id} in channel {channel_id}.")
            except Exception as e:
                session.rollback()
                self.logger.error(f"Failed to clear context for user {user_id} in channel {channel_id}: {e}")