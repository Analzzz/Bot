from sqlalchemy import Column, Integer, String, Text, Boolean, DateTime, ForeignKey, Float
from sqlalchemy.ext.declarative import declarative_base
from sqlalchemy.orm import relationship
from sqlalchemy.sql import func
import datetime

# Base class for declarative models.
# This Base will be used by all SQLAlchemy models in the application.
Base = declarative_base()

class UserProfile(Base):
    """
    Represents a user profile within the bot's database.
    Stores information about Discord users interacting with the bot,
    including their preferences and historical data.
    """
    __tablename__ = 'user_profiles'

    id = Column(Integer, primary_key=True, autoincrement=False) # Discord User ID (snowflake)
    username = Column(String(256), nullable=False)
    discriminator = Column(String(4), nullable=True) # Old discriminator, often '0000' for new usernames
    global_name = Column(String(256), nullable=True) # New global display name for users
    avatar_url = Column(String(512), nullable=True)
    created_at = Column(DateTime, default=func.now(), nullable=False) # When the profile was first recorded
    last_seen_at = Column(DateTime, default=func.now(), onupdate=func.now(), nullable=False) # Last interaction timestamp
    is_bot_owner = Column(Boolean, default=False, nullable=False) # True if the user is a designated bot owner
    reputation = Column(Integer, default=0, nullable=False) # A simple reputation score for the user
    context_preference = Column(String(50), default='medium', nullable=False) # e.g., 'short', 'medium', 'long' for AI context length

    # Relationships
    interactions = relationship("Interaction", back_populates="user")
    conversation_contexts = relationship("ConversationContext", back_populates="user")

    def __repr__(self):
        return f"<UserProfile(id={self.id}, username='{self.username}', global_name='{self.global_name}')>"

class GuildProfile(Base):
    """
    Represents a Discord guild (server) profile within the bot's database.
    Stores guild-specific settings and information, such as custom prefixes.
    """
    __tablename__ = 'guild_profiles'

    id = Column(Integer, primary_key=True, autoincrement=False) # Discord Guild ID (snowflake)
    name = Column(String(256), nullable=False)
    owner_id = Column(Integer, nullable=False) # Discord User ID of the guild owner
    created_at = Column(DateTime, default=func.now(), nullable=False) # When the guild was first recorded
    last_seen_at = Column(DateTime, default=func.now(), onupdate=func.now(), nullable=False) # Last interaction timestamp in this guild
    bot_join_date = Column(DateTime, default=func.now(), nullable=False) # When the bot joined this guild
    prefix = Column(String(10), default='!', nullable=False) # Custom bot prefix for this guild
    ai_enabled = Column(Boolean, default=True, nullable=False) # Whether AI features are enabled in this guild

    # Relationships
    interactions = relationship("Interaction", back_populates="guild")
    conversation_contexts = relationship("ConversationContext", back_populates="guild")

    def __repr__(self):
        return f"<GuildProfile(id={self.id}, name='{self.name}')>"

class Interaction(Base):
    """
    Records every significant interaction the bot has, including commands,
    AI queries, and responses. Essential for auditing, learning, and explicability.
    """
    __tablename__ = 'interactions'

    id = Column(Integer, primary_key=True, autoincrement=True)
    user_id = Column(Integer, ForeignKey('user_profiles.id'), nullable=False)
    guild_id = Column(Integer, ForeignKey('guild_profiles.id'), nullable=True) # Null for Direct Messages (DMs)
    channel_id = Column(Integer, nullable=False) # Discord Channel ID
    message_id = Column(Integer, nullable=False) # Discord Message ID (of the user's message)
    timestamp = Column(DateTime, default=func.now(), nullable=False)
    command_used = Column(String(100), nullable=True) # e.g., 'ask', 'code', 'help', if a command was explicitly used
    user_input = Column(Text, nullable=False) # The raw message content from the user
    bot_response = Column(Text, nullable=True) # The bot's generated response (can be empty for some interaction types)
    response_type = Column(String(50), nullable=False) # e.g., 'AI_GEN', 'COMMAND_ACK', 'ERROR', 'DM_RESPONSE', 'KNOWLEDGE_QUERY'
    tokens_used = Column(Integer, nullable=True) # Number of tokens used for AI interaction (input + output)
    is_successful = Column(Boolean, default=True, nullable=False) # Indicates if the interaction completed successfully
    error_message = Column(Text, nullable=True) # Stores error details if the interaction was not successful

    # Relationships
    user = relationship("UserProfile", back_populates="interactions")
    guild = relationship("GuildProfile", back_populates="interactions")
    source_for_nodes = relationship("KnowledgeNode", back_populates="source_interaction")
    source_for_edges = relationship("KnowledgeEdge", back_populates="source_interaction")

    def __repr__(self):
        return f"<Interaction(id={self.id}, user_id={self.user_id}, type='{self.response_type}', timestamp={self.timestamp})>"

class ConversationContext(Base):
    """
    Stores long-term conversation context for users/channels, enabling
    the bot to maintain relevance across extended interactions and provide
    contextualized responses.
    """
    __tablename__ = 'conversation_contexts'

    id = Column(Integer, primary_key=True, autoincrement=True)
    user_id = Column(Integer, ForeignKey('user_profiles.id'), nullable=False)
    channel_id = Column(Integer, nullable=False) # Discord Channel ID
    guild_id = Column(Integer, ForeignKey('guild_profiles.id'), nullable=True) # Null for DMs
    last_updated = Column(DateTime, default=func.now(), onupdate=func.now(), nullable=False) # Last time this context was updated
    # context_data can store serialized conversation history (e.g., JSON string of messages)
    # or a more abstract representation of the context, like a list of key-value pairs.
    context_data = Column(Text, nullable=True)
    summary = Column(Text, nullable=True) # A short, AI-generated summary of the ongoing conversation
    is_active = Column(Boolean, default=True, nullable=False) # True if this context is currently being actively used

    # Relationships
    user = relationship("UserProfile", back_populates="conversation_contexts")
    guild = relationship("GuildProfile", back_populates="conversation_contexts")

    def __repr__(self):
        return f"<ConversationContext(id={self.id}, user_id={self.user_id}, channel_id={self.channel_id}, active={self.is_active})>"

class KnowledgeNode(Base):
    """
    Represents a node in the bot's knowledge graph.
    Stores facts, concepts, entities, code snippets, or any discrete piece of knowledge
    learned by the bot.
    """
    __tablename__ = 'knowledge_nodes'

    id = Column(Integer, primary_key=True, autoincrement=True)
    node_type = Column(String(100), nullable=False) # e.g., 'Concept', 'Entity', 'Person', 'Event', 'CodeSnippet', 'Function'
    name = Column(String(512), nullable=False, unique=True) # The unique name/label of the node (e.g., "Python", "SQLAlchemy ORM")
    description = Column(Text, nullable=True) # Detailed description or content of the node
    created_at = Column(DateTime, default=func.now(), nullable=False)
    last_updated = Column(DateTime, default=func.now(), onupdate=func.now(), nullable=False)
    # Link to the interaction that led to the creation or significant update of this node
    source_interaction_id = Column(Integer, ForeignKey('interactions.id'), nullable=True)
    # Store embedding as a string (e.g., comma-separated floats) or BLOB for vector similarity search.
    embedding = Column(Text, nullable=True) # Vector embedding of the node's content for semantic search

    # Relationships
    source_interaction = relationship("Interaction", back_populates="source_for_nodes")
    # Outgoing and incoming edges are defined via the KnowledgeEdge model

    def __repr__(self):
        return f"<KnowledgeNode(id={self.id}, type='{self.node_type}', name='{self.name}')>"

class KnowledgeEdge(Base):
    """
    Represents an edge (relationship) between two nodes in the bot's knowledge graph.
    Defines how different pieces of knowledge are connected.
    """
    __tablename__ = 'knowledge_edges'

    id = Column(Integer, primary_key=True, autoincrement=True)
    source_node_id = Column(Integer, ForeignKey('knowledge_nodes.id'), nullable=False)
    target_node_id = Column(Integer, ForeignKey('knowledge_nodes.id'), nullable=False)
    relation_type = Column(String(100), nullable=False) # e.g., 'is_a', 'has_property', 'related_to', 'causes', 'generates', 'implements'
    strength = Column(Float, default=1.0, nullable=False) # Confidence or strength of the relation (0.0 - 1.0)
    description = Column(Text, nullable=True) # Optional detailed description of the relationship
    created_at = Column(DateTime, default=func.now(), nullable=False)
    last_updated = Column(DateTime, default=func.now(), onupdate=func.now(), nullable=False)
    # Link to the interaction that led to the creation or significant update of this edge
    source_interaction_id = Column(Integer, ForeignKey('interactions.id'), nullable=True)

    # Relationships
    source_node = relationship("KnowledgeNode", foreign_keys=[source_node_id], backref="outgoing_edges")
    target_node = relationship("KnowledgeNode", foreign_keys=[target_node_id], backref="incoming_edges")
    source_interaction = relationship("Interaction", back_populates="source_for_edges")

    def __repr__(self):
        return f"<KnowledgeEdge(id={self.id}, '{self.source_node_id}' --'{self.relation_type}'--> '{self.target_node_id}')>"

# Note: The actual database engine creation and session management will be handled
# in a separate module (e.g., src/data/database.py) that imports these models.
# This file solely defines the SQLAlchemy ORM models.