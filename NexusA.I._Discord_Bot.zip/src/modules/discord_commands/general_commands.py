import discord
from discord.ext import commands
import logging
import datetime

from config.settings import BOT_PREFIX, LOG_LEVEL
from src.core.database_manager import DatabaseManager # Included for potential future use in general commands

class GeneralCommands(commands.Cog):
    """
    A cog for general purpose commands like help, info, and ping.
    These commands provide basic utility and information about the bot.
    """
    def __init__(self, bot: commands.Bot):
        self.bot = bot
        self.logger = logging.getLogger(__name__)
        self.logger.setLevel(LOG_LEVEL)
        self.start_time = datetime.datetime.now()
        # self.db_manager = DatabaseManager() # Uncomment and use if database interaction is needed in these commands

    @commands.command(name="ping", help="Checks the bot's latency to Discord.")
    async def ping(self, ctx: commands.Context):
        """
        Responds with the bot's current latency (ping) in milliseconds.
        """
        latency_ms = round(self.bot.latency * 1000)
        await ctx.send(f"Pong! 🏓 Latency: {latency_ms}ms")
        self.logger.info(f"Ping command executed by {ctx.author} (ID: {ctx.author.id}) in {ctx.guild} (ID: {ctx.guild.id}). Latency: {latency_ms}ms")

    @commands.command(name="info", help="Displays information about the bot.")
    async def info(self, ctx: commands.Context):
        """
        Provides general information about the NexusA.I. bot,
        including its developer, uptime, server count, and current latency.
        """
        uptime = datetime.datetime.now() - self.start_time
        hours, remainder = divmod(uptime.total_seconds(), 3600)
        minutes, seconds = divmod(remainder, 60)

        embed = discord.Embed(
            title="NexusA.I. Bot Information",
            description="A highly sophisticated and modular Discord bot powered by Google Gemini AI.",
            color=discord.Color.blue()
        )
        embed.add_field(name="Developer", value="NexusA.I. Team", inline=True)
        embed.add_field(name="Discord.py Version", value=discord.__version__, inline=True)
        embed.add_field(name="Servers", value=f"{len(self.bot.guilds)}", inline=True)
        embed.add_field(name="Uptime", value=f"{int(hours)}h {int(minutes)}m {int(seconds)}s", inline=True)
        embed.add_field(name="Prefix", value=f"`{BOT_PREFIX}`", inline=True)
        embed.add_field(name="Latency", value=f"{round(self.bot.latency * 1000)}ms", inline=True)
        
        # Set footer with requester's info
        requester_avatar_url = ctx.author.avatar.url if ctx.author.avatar else ctx.author.default_avatar.url
        embed.set_footer(text=f"Requested by {ctx.author.display_name}", icon_url=requester_avatar_url)
        
        # Set thumbnail with bot's avatar
        bot_avatar_url = self.bot.user.avatar.url if self.bot.user.avatar else self.bot.user.default_avatar.url
        embed.set_thumbnail(url=bot_avatar_url)

        await ctx.send(embed=embed)
        self.logger.info(f"Info command executed by {ctx.author} (ID: {ctx.author.id}) in {ctx.guild} (ID: {ctx.guild.id}).")

    @commands.command(name="help", help="Shows this help message or help for a specific command.")
    async def custom_help(self, ctx: commands.Context, *, command_name: str = None):
        """
        Provides a custom help message for the bot's commands.
        If a command name is provided, it shows specific help for that command.
        Otherwise, it lists general commands available in this cog.
        """
        if command_name:
            # Attempt to find the command across all loaded cogs
            command = self.bot.get_command(command_name)
            if command:
                embed = discord.Embed(
                    title=f"Help for `{BOT_PREFIX}{command.name}`",
                    description=command.help or "No detailed help available for this command.",
                    color=discord.Color.green()
                )
                if command.aliases:
                    embed.add_field(name="Aliases", value=", ".join(command.aliases), inline=False)
                # Note: command.usage is not automatically populated. You'd set it manually or parse from signature.
                # For simplicity, we'll just show the basic command name.
                embed.add_field(name="Usage", value=f"`{BOT_PREFIX}{command.name} {command.signature}`", inline=False)
                await ctx.send(embed=embed)
            else:
                await ctx.send(f"Sorry, I couldn't find a command named `{command_name}`. Please check the spelling.")
            self.logger.info(f"Help command executed by {ctx.author} (ID: {ctx.author.id}) for specific command '{command_name}'.")
        else:
            # General help message listing commands in this cog
            embed = discord.Embed(
                title="NexusA.I. Bot General Commands",
                description=f"Here are some general commands you can use. My prefix is `{BOT_PREFIX}`.\n"
                            f"Use `{BOT_PREFIX}help <command>` for more specific information.",
                color=discord.Color.purple()
            )
            
            general_commands_list = []
            # Iterate through commands registered to this specific cog
            for command in self.walk_commands():
                # Ensure we only list commands that are part of this cog
                if command.cog_name == self.qualified_name:
                    general_commands_list.append(f"`{BOT_PREFIX}{command.name}` - {command.help}")
            
            if general_commands_list:
                embed.add_field(name="Available Commands", value="\n".join(general_commands_list), inline=False)
            else:
                embed.add_field(name="Available Commands", value="No general commands found in this module.", inline=False)

            await ctx.send(embed=embed)
            self.logger.info(f"General help command executed by {ctx.author} (ID: {ctx.author.id}).")

async def setup(bot: commands.Bot):
    """
    Adds the GeneralCommands cog to the bot.
    This function is called when the cog is loaded.
    """
    await bot.add_cog(GeneralCommands(bot))
    logging.getLogger(__name__).info("GeneralCommands cog loaded successfully.")