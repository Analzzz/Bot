import discord
from discord.ext import commands
import logging
import google.generativeai as genai

from config.settings import (
    GOOGLE_GEMINI_API_KEY,
    GEMINI_MAX_TOKENS,
    GEMINI_TEMPERATURE,
    GEMINI_TOP_P,
    GEMINI_TOP_K,
    LOG_LEVEL
)
from src.core.database_manager import DatabaseManager
from src.data.models import Interaction, UserProfile, ConversationContext

class AICommands(commands.Cog):
    """
    A cog for AI-powered commands, allowing direct interaction with the Google Gemini model.
    Includes commands for general questions and code generation/optimization.
    """
    def __init__(self, bot: commands.Bot):
        self.bot = bot
        self.logger = logging.getLogger(__name__)
        self.logger.setLevel(LOG_LEVEL)
        self.db_manager = DatabaseManager()

        # Configure Google Gemini API
        if not GOOGLE_GEMINI_API_KEY:
            self.logger.error("GOOGLE_GEMINI_API_KEY is not set. AI commands will not function.")
            self.model = None
        else:
            try:
                genai.configure(api_key=GOOGLE_GEMINI_API_KEY)
                self.model = genai.GenerativeModel(
                    model_name="gemini-pro", # Using gemini-pro for text-based interactions
                    generation_config=genai.GenerationConfig(
                        temperature=GEMINI_TEMPERATURE,
                        top_p=GEMINI_TOP_P,
                        top_k=GEMINI_TOP_K,
                        max_output_tokens=GEMINI_MAX_TOKENS,
                    ),
                    # Safety settings are set to BLOCK_NONE for broader response generation,
                    # but consider adjusting based on application requirements and user base.
                    safety_settings=[
                        {"category": "HARM_CATEGORY_HARASSMENT", "threshold": "BLOCK_NONE"},
                        {"category": "HARM_CATEGORY_HATE_SPEECH", "threshold": "BLOCK_NONE"},
                        {"category": "HARM_CATEGORY_SEXUALLY_EXPLICIT", "threshold": "BLOCK_NONE"},
                        {"category": "HARM_CATEGORY_DANGEROUS_CONTENT", "threshold": "BLOCK_NONE"},
                    ]
                )
                self.logger.info("Google Gemini model initialized successfully.")
            except Exception as e:
                self.logger.critical(f"Failed to initialize Google Gemini model: {e}")
                self.model = None

    async def _record_interaction(self, ctx: commands.Context, command_name: str, prompt: str, response_text: str, success: bool, error_message: str = None):
        """Helper to record interactions in the database."""
        with self.db_manager.get_session() as session:
            # Ensure UserProfile exists for the interacting user
            user_profile = session.query(UserProfile).filter_by(discord_id=ctx.author.id).first()
            if not user_profile:
                user_profile = UserProfile(
                    discord_id=ctx.author.id,
                    username=ctx.author.name,
                    global_name=ctx.author.global_name if hasattr(ctx.author, 'global_name') else ctx.author.name,
                    is_bot=ctx.author.bot
                )
                session.add(user_profile)
                session.flush() # Flush to get the user_profile.id before committing

            interaction = Interaction(
                user_id=user_profile.id,
                guild_id=ctx.guild.id if ctx.guild else None,
                channel_id=ctx.channel.id,
                command_name=command_name,
                input_content=prompt,
                response_content=response_text,
                response_type="AI_GENERATION",
                success=success,
                error_message=error_message
            )
            session.add(interaction)
            session.commit()
            self.logger.debug(f"Recorded interaction for user {ctx.author.id}, command '{command_name}'. Success: {success}")

    @commands.command(name="ask", help="Ask the AI a question. Usage: !ask <your question>")
    @commands.cooldown(1, 5, commands.BucketType.user) # 1 use per 5 seconds per user
    async def ask(self, ctx: commands.Context, *, query: str):
        """
        Asks the AI a general question and returns its response.
        """
        if not self.model:
            await ctx.send("AI services are currently unavailable. Please check the bot's configuration.")
            self.logger.error(f"AI command 'ask' failed: Model not initialized for user {ctx.author.id}.")
            await self._record_interaction(ctx, "ask", query, "AI services unavailable.", False, "Model not initialized")
            return

        if not query.strip():
            await ctx.send("Please provide a question for the AI to answer.")
            await self._record_interaction(ctx, "ask", query, "No query provided.", False, "Empty query")
            return

        self.logger.info(f"AI 'ask' command received from {ctx.author.id} in {ctx.guild.id if ctx.guild else 'DM'}: '{query}'")
        
        try:
            async with ctx.typing():
                response = await self.model.generate_content(query)
                
                # Check for safety feedback first
                if response.prompt_feedback and response.prompt_feedback.safety_ratings:
                    blocked = False
                    for rating in response.prompt_feedback.safety_ratings:
                        if rating.blocked:
                            blocked = True
                            self.logger.warning(f"AI 'ask' command blocked due to safety concerns for user {ctx.author.id}. Category: {rating.category}, Threshold: {rating.threshold}")
                            await ctx.send("Your request was blocked by the AI's safety filters. Please try rephrasing your question.")
                            await self._record_interaction(ctx, "ask", query, "Blocked by safety filters.", False, f"Safety block: {rating.category}")
                            return

                if response.text:
                    ai_response = response.text
                    # Discord message length limit is 2000 characters
                    if len(ai_response) > 2000:
                        ai_response = ai_response[:1997] + "..." # Truncate if too long
                        await ctx.send(f"The response was too long, truncated:\n{ai_response}")
                    else:
                        await ctx.send(ai_response)
                    self.logger.info(f"AI 'ask' command successful for {ctx.author.id}.")
                    await self._record_interaction(ctx, "ask", query, ai_response, True)
                else:
                    await ctx.send("I couldn't generate a response for that. The AI might not have understood, or there might be an issue.")
                    self.logger.warning(f"AI 'ask' command returned no text for user {ctx.author.id}. Response: {response}")
                    await self._record_interaction(ctx, "ask", query, "No text in AI response.", False, "AI returned no text")

        except Exception as e:
            self.logger.error(f"Error processing AI 'ask' command for {ctx.author.id}: {e}", exc_info=True)
            await ctx.send("An error occurred while trying to get a response from the AI. Please try again later.")
            await self._record_interaction(ctx, "ask", query, f"Error: {e}", False, str(e))

    @commands.command(name="code", help="Request code generation or optimization from the AI. Usage: !code <your code request>")
    @commands.cooldown(1, 10, commands.BucketType.user) # 1 use per 10 seconds per user, code generation can be heavier
    async def code(self, ctx: commands.Context, *, query: str):
        """
        Requests code generation or optimization from the AI.
        """
        if not self.model:
            await ctx.send("AI services are currently unavailable. Please check the bot's configuration.")
            self.logger.error(f"AI command 'code' failed: Model not initialized for user {ctx.author.id}.")
            await self._record_interaction(ctx, "code", query, "AI services unavailable.", False, "Model not initialized")
            return

        if not query.strip():
            await ctx.send("Please provide a description of the code you need or want to optimize.")
            await self._record_interaction(ctx, "code", query, "No query provided.", False, "Empty query")
            return

        self.logger.info(f"AI 'code' command received from {ctx.author.id} in {ctx.guild.id if ctx.guild else 'DM'}: '{query}'")
        
        # Craft a specific prompt for code generation
        code_prompt = f"Generate or optimize code based on the following request. Provide the code in a markdown code block, and explain it briefly:\n\nRequest: {query}"

        try:
            async with ctx.typing():
                response = await self.model.generate_content(code_prompt)

                # Check for safety feedback first
                if response.prompt_feedback and response.prompt_feedback.safety_ratings:
                    blocked = False
                    for rating in response.prompt_feedback.safety_ratings:
                        if rating.blocked:
                            blocked = True
                            self.logger.warning(f"AI 'code' command blocked due to safety concerns for user {ctx.author.id}. Category: {rating.category}, Threshold: {rating.threshold}")
                            await ctx.send("Your code request was blocked by the AI's safety filters. Please try rephrasing your request.")
                            await self._record_interaction(ctx, "code", query, "Blocked by safety filters.", False, f"Safety block: {rating.category}")
                            return

                if response.text:
                    ai_response = response.text
                    # Discord message length limit is 2000 characters
                    if len(ai_response) > 2000:
                        # Attempt to find the end of a code block or just truncate
                        # This is a heuristic and might not always perfectly close code blocks
                        if "```" in ai_response[1900:]: # Look for a closing code block near the end
                            ai_response = ai_response[:ai_response.rfind("```") + 3] + "\n... (truncated)"
                        else:
                            ai_response = ai_response[:1997] + "..." # Truncate if no clear code block end
                        await ctx.send(f"The response was too long, truncated:\n{ai_response}")
                    else:
                        await ctx.send(ai_response)
                    self.logger.info(f"AI 'code' command successful for {ctx.author.id}.")
                    await self._record_interaction(ctx, "code", query, ai_response, True)
                else:
                    await ctx.send("I couldn't generate code for that. The AI might not have understood, or there might be an issue.")
                    self.logger.warning(f"AI 'code' command returned no text for user {ctx.author.id}. Response: {response}")
                    await self._record_interaction(ctx, "code", query, "No text in AI response.", False, "AI returned no text")

        except Exception as e:
            self.logger.error(f"Error processing AI 'code' command for {ctx.author.id}: {e}", exc_info=True)
            await ctx.send("An error occurred while trying to generate code. Please try again later.")
            await self._record_interaction(ctx, "code", query, f"Error: {e}", False, str(e))

async def setup(bot: commands.Bot):
    """
    Adds the AICommands cog to the bot.
    This function is called when the cog is loaded.
    """
    await bot.add_cog(AICommands(bot))
    logging.getLogger(__name__).info("AICommands cog loaded successfully.")