import logging
from contextlib import contextmanager
from sqlalchemy import create_engine
from sqlalchemy.orm import sessionmaker, Session
from config.settings import DATABASE_URL, LOG_LEVEL
from src.data.models import Base

class DatabaseManager:
    """
    Manages the database connection and session lifecycle for the application.
    Implements a singleton pattern to ensure only one database engine and
    session factory exist throughout the application's lifetime.
    """
    _instance = None
    _initialized = False

    def __new__(cls, *args, **kwargs):
        if cls._instance is None:
            cls._instance = super(DatabaseManager, cls).__new__(cls)
        return cls._instance

    def __init__(self):
        if not self._initialized:
            self.logger = logging.getLogger(__name__)
            self.logger.setLevel(LOG_LEVEL)

            try:
                # Configure the SQLAlchemy engine
                # echo=True for debugging SQL statements, set based on LOG_LEVEL
                echo_sql = LOG_LEVEL == "DEBUG"
                self.engine = create_engine(DATABASE_URL, echo=echo_sql)
                
                # Configure the sessionmaker
                # autocommit=False: transactions are not committed automatically
                # autoflush=False: objects are not flushed to the database automatically
                # bind=self.engine: binds the session to our engine
                self.SessionLocal = sessionmaker(autocommit=False, autoflush=False, bind=self.engine)
                
                self.logger.info(f"DatabaseManager initialized with URL: {DATABASE_URL}")
                self._initialized = True
            except Exception as e:
                self.logger.critical(f"Failed to initialize DatabaseManager: {e}", exc_info=True)
                raise

    def create_all_tables(self):
        """
        Creates all tables defined in the SQLAlchemy Base metadata.
        This should be called once at application startup.
        """
        try:
            self.logger.info("Attempting to create all database tables...")
            Base.metadata.create_all(self.engine)
            self.logger.info("All database tables created or already exist.")
        except Exception as e:
            self.logger.error(f"Error creating database tables: {e}", exc_info=True)
            raise

    @contextmanager
    def get_session(self) -> Session:
        """
        Provides a SQLAlchemy session within a context manager.
        Ensures the session is properly closed and transactions are handled.

        Yields:
            sqlalchemy.orm.Session: A new database session.

        Usage:
            with db_manager.get_session() as session:
                # Perform database operations with 'session'
                user = UserProfile(username="test")
                session.add(user)
        """
        session = self.SessionLocal()
        try:
            yield session
            session.commit()
        except Exception as e:
            session.rollback()
            self.logger.error(f"Session encountered an error, rolling back: {e}", exc_info=True)
            raise
        finally:
            session.close()
            self.logger.debug("Database session closed.")

# Global instance for easy access throughout the application
db_manager = DatabaseManager()