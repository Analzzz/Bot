import logging
from discord.ext import commands

# Get a logger for this module
logger = logging.getLogger(__name__)

# Define a list of initial cogs (extensions) to load.
# These paths should correspond to Python modules containing cog classes.
# As no specific cogs have been defined yet, this list is a placeholder.
# In a real application, this would be populated with paths like "cogs.general", "cogs.ai_commands", etc.
INITIAL_COGS = [
    # Example: "cogs.general_commands",
    # Example: "cogs.ai_interaction",
    # Example: "cogs.admin_tools",
]

async def load_bot_extensions(bot: commands.Bot):
    """
    Loads all specified cogs (extensions) into the bot instance.
    This function encapsulates the logic for dynamically loading bot modules,
    contributing to the bot's modular and scalable architecture.

    Args:
        bot (commands.Bot): The bot instance to load extensions into.
    """
    logger.info("Attempting to load initial bot extensions...")
    for extension in INITIAL_COGS:
        try:
            await bot.load_extension(extension)
            logger.info(f"Successfully loaded extension: {extension}")
        except commands.ExtensionAlreadyLoaded:
            logger.warning(f"Extension '{extension}' is already loaded. Skipping.")
        except commands.ExtensionNotFound:
            logger.error(f"Extension '{extension}' not found. Please check the path and file existence.")
        except commands.NoEntryPointError:
            logger.error(f"Extension '{extension}' has no 'setup' function. Cogs must define a setup function.")
        except Exception as e:
            logger.exception(f"Failed to load extension '{extension}': {e}")
    
    logger.info("Initial extension loading process complete.")

# Additional core logic or helper functions related to bot events or state
# can be added here if they are not directly methods of the NexusAI class
# and are not specific to individual cogs.
# For instance, a function to register global event listeners that are not
# part of a cog, or utility functions for bot-wide operations.
# Currently, the main event handlers (on_ready, on_command_error) are defined
# within the NexusAI class in main.py, and other events are expected to be
# handled by specific cogs.