import os
import logging
import discord
from discord.ext import commands
from dotenv import load_dotenv

# Load environment variables from .env file
# This must be called before importing settings that rely on env vars.
load_dotenv()

# Import settings after loading environment variables
from config.settings import (
    DISCORD_BOT_TOKEN,
    BOT_PREFIX,
    DEFAULT_INTENTS,
    OWNER_IDS,
    LOG_LEVEL,
    DATA_DIR,
    LOG_DIR
)

# --- Setup Directories ---
def setup_directories():
    """Ensures necessary directories for persistent data and logs exist."""
    try:
        os.makedirs(DATA_DIR, exist_ok=True)
        os.makedirs(LOG_DIR, exist_ok=True)
        print(f"Ensured data directory: {DATA_DIR}")
        print(f"Ensured logs directory: {LOG_DIR}")
    except OSError as e:
        print(f"Error creating directories: {e}")
        raise

# --- Setup Logging ---
def setup_logging():
    """Configures the logging system for the bot."""
    log_file_path = os.path.join(LOG_DIR, "nexusai_bot.log")
    
    # Create a formatter for log messages
    log_formatter = logging.Formatter(
        '%(asctime)s - %(name)s - %(levelname)s - %(message)s'
    )

    # File handler: writes logs to a file
    file_handler = logging.FileHandler(log_file_path, encoding='utf-8')
    file_handler.setFormatter(log_formatter)
    
    # Console handler: prints logs to the console
    console_handler = logging.StreamHandler()
    console_handler.setFormatter(log_formatter)

    # Get the root logger
    root_logger = logging.getLogger()
    # Set the global logging level from settings
    root_logger.setLevel(LOG_LEVEL) 

    # Add handlers to the root logger
    root_logger.addHandler(file_handler)
    root_logger.addHandler(console_handler)

    # Set discord.py logger levels to INFO to avoid excessive debug output
    logging.getLogger('discord').setLevel(logging.INFO)
    logging.getLogger('discord.http').setLevel(logging.INFO)
    logging.getLogger('discord.gateway').setLevel(logging.INFO)
    
    logging.info("Logging system initialized.")
    logging.info(f"Log level set to: {LOG_LEVEL}")
    logging.info(f"Logs are being written to: {log_file_path}")

# --- Bot Initialization ---
class NexusAI(commands.Bot):
    """
    The main Discord bot client for NexusA.I.
    Handles bot initialization, event handling, and cog loading.
    """
    def __init__(self):
        super().__init__(
            command_prefix=commands.when_mentioned_or(BOT_PREFIX), # Bot responds to prefix or mentions
            intents=DEFAULT_INTENTS,
            owner_ids=OWNER_IDS,
            help_command=None # Custom help command will be implemented in a cog
        )
        self.logger = logging.getLogger(__name__)
        # List to hold paths to initial cogs to load on startup
        self.initial_extensions = [] 

    async def setup_hook(self):
        """
        Called after the bot is connected and ready to load extensions.
        This is the recommended place to load cogs.
        """
        self.logger.info("Running setup_hook to load extensions...")
        for extension in self.initial_extensions:
            try:
                await self.load_extension(extension)
                self.logger.info(f"Successfully loaded extension: {extension}")
            except Exception as e:
                self.logger.error(f"Failed to load extension {extension}: {e}", exc_info=True)

    async def on_ready(self):
        """Event fired when the bot is fully ready and connected to Discord."""
        self.logger.info(f"Logged in as {self.user} (ID: {self.user.id})")
        self.logger.info(f"Discord.py version: {discord.__version__}")
        self.logger.info(f"Bot prefix: '{BOT_PREFIX}'")
        print(f"Bot is ready! Logged in as {self.user.name}")
        print(f"Bot ID: {self.user.id}")
        # Set bot's activity status
        await self.change_presence(activity=discord.Game(name=f"{BOT_PREFIX}help | NexusA.I."))

    async def on_command_error(self, ctx: commands.Context, error: commands.CommandError):
        """Global command error handler."""
        if isinstance(error, commands.CommandNotFound):
            self.logger.warning(f"Command not found: '{ctx.message.content}' by {ctx.author} (ID: {ctx.author.id})")
            # await ctx.send("Sorry, I don't recognize that command. Use `!help` to see available commands.")
        elif isinstance(error, commands.MissingRequiredArgument):
            self.logger.warning(f"Missing argument for command '{ctx.command}': {error}")
            await ctx.send(f"Missing argument: `{error}`. Please check the command usage.")
        elif isinstance(error, commands.BadArgument):
            self.logger.warning(f"Bad argument for command '{ctx.command}': {error}")
            await ctx.send(f"Bad argument: `{error}`. Please check your input.")
        elif isinstance(error, commands.NoPrivateMessage):
            self.logger.warning(f"Command '{ctx.command}' used in DM, but not allowed.")
            await ctx.send("This command cannot be used in private messages.")
        elif isinstance(error, commands.NotOwner):
            self.logger.warning(f"Unauthorized command usage by {ctx.author.id} for command '{ctx.command}'.")
            await ctx.send("You do not have permission to use this command.")
        elif isinstance(error, commands.CommandOnCooldown):
            self.logger.warning(f"Command '{ctx.command}' on cooldown for {ctx.author}. Retry after {error.retry_after:.2f}s.")
            await ctx.send(f"This command is on cooldown. Please try again in `{error.retry_after:.2f}` seconds.")
        elif isinstance(error, commands.CheckFailure):
            self.logger.warning(f"Command '{ctx.command}' failed check for {ctx.author}.")
            await ctx.send("You don't have the necessary permissions or conditions to run this command.")
        else:
            self.logger.exception(f"Unhandled command error in '{ctx.command}': {error}", exc_info=True)
            await ctx.send(f"An unexpected error occurred while running the command: `{error}`")

# --- Main execution block ---
if __name__ == "__main__":
    try:
        # 1. Setup necessary directories
        setup_directories()
        
        # 2. Configure logging
        setup_logging()

        # 3. Initialize the bot instance
        bot = NexusAI()
        
        # 4. Define initial extensions (cogs) to load
        # As no cogs are defined yet, this list is empty.
        # Example of how cogs would be added:
        # bot.initial_extensions = [
        #     "src.cogs.general",  # For general commands like help, ping
        #     "src.cogs.ai_commands", # For AI interaction commands
        #     "src.cogs.admin"     # For owner-only commands
        # ]

        # 5. Run the bot
        bot.run(DISCORD_BOT_TOKEN)

    except ValueError as ve:
        # This catches configuration errors from settings.py if essential env vars are missing
        print(f"Configuration Error: {ve}")
        logging.critical(f"Configuration Error: {ve}")
    except discord.LoginFailure:
        print("Failed to log in. Please check your DISCORD_BOT_TOKEN in your .env file.")
        logging.critical("Failed to log in. Please check your DISCORD_BOT_TOKEN.")
    except Exception as e:
        print(f"An unhandled error occurred during bot startup: {e}")
        logging.critical(f"An unhandled error occurred during bot startup: {e}", exc_info=True)