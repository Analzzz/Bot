import os
import discord # Required for discord.Intents

# --- Core Bot Settings ---
# These values are expected to be loaded from environment variables,
# typically via a call to `load_dotenv()` at the application's entry point (e.g., main.py).
DISCORD_BOT_TOKEN = os.getenv("DISCORD_BOT_TOKEN")
GOOGLE_GEMINI_API_KEY = os.getenv("GOOGLE_GEMINI_API_KEY")
DATABASE_URL = os.getenv("DATABASE_URL", "sqlite:///./data/nexusai.db")

# --- Discord Bot Specific Settings ---
BOT_PREFIX = "!" # The default prefix for bot commands (e.g., !help, !ask)
OWNER_IDS = [] # A list of Discord user IDs who are considered bot owners.
               # Commands restricted to owners will check against this list.
               # Example: OWNER_IDS = [123456789012345678, 987654321098765432]

# Discord Intents: Define which events your bot wants to receive from Discord.
# It's crucial to enable necessary intents both here and in your bot's application
# settings on the Discord Developer Portal.
# MESSAGE_CONTENT is a privileged intent and must be explicitly enabled.
DEFAULT_INTENTS = discord.Intents.default()
DEFAULT_INTENTS.message_content = True # Required to read message content for commands and AI processing
DEFAULT_INTENTS.members = True         # Required for member-related events, e.g., fetching user info
DEFAULT_INTENTS.guilds = True          # Required for guild-related events, e.g., joining/leaving guilds
# Add other intents as needed for specific features (e.g., reactions, voice_states)
# DEFAULT_INTENTS.reactions = True
# DEFAULT_INTENTS.voice_states = True

# --- AI Specific Settings (Google Gemini) ---
GEMINI_MAX_TOKENS = 2048   # Maximum number of tokens for AI generated responses
GEMINI_TEMPERATURE = 0.7   # Controls the randomness of the AI's output. Higher values mean more random. (0.0 - 1.0)
GEMINI_TOP_P = 0.95        # Nucleus sampling: filters out low probability tokens. (0.0 - 1.0)
GEMINI_TOP_K = 40          # Top-k sampling: considers only the top K most likely next tokens.

# --- Logging Settings ---
LOG_LEVEL = os.getenv("LOG_LEVEL", "INFO").upper() # Default logging level (DEBUG, INFO, WARNING, ERROR, CRITICAL)

# --- File System Paths ---
DATA_DIR = "./data" # Directory for persistent data (e.g., database, memory files)
LOG_DIR = "./logs"  # Directory for log files

# --- Runtime Checks ---
# Ensure essential environment variables are provided.
# The bot should not start without these critical keys.
if not DISCORD_BOT_TOKEN:
    raise ValueError("DISCORD_BOT_TOKEN environment variable not set. Please check your .env file.")
if not GOOGLE_GEMINI_API_KEY:
    raise ValueError("GOOGLE_GEMINI_API_KEY environment variable not set. Please check your .env file.")